package org.ugp.serialx;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import org.ugp.serialx.converters.BooleanConverter;
import org.ugp.serialx.converters.CharacterConverter;
import org.ugp.serialx.converters.DataConverter;
import org.ugp.serialx.converters.DataParser;
import org.ugp.serialx.converters.NullConverter;
import org.ugp.serialx.converters.NumberConverter;
import org.ugp.serialx.converters.ObjectConverter;
import org.ugp.serialx.converters.SerializableBase64Converter;
import org.ugp.serialx.converters.StringConverter;
import org.ugp.serialx.converters.VariableConverter;
import org.ugp.serialx.protocols.SerializationProtocol;
import org.ugp.serialx.protocols.SerializationProtocol.ProtocolRegistry;

/**
 * This is implementation of {@link JussSerializer} for serializing in <a href = "https://www.json.org/json-en.html">Json</a>!
 * It should generate and work with .josn files!
 * <br><br>
 * Note: No Json specific syntax checks are made here except some small formating changes to ensure Json syntax correctness but it will let you to use some Juss features freely so you can easily end up with some Json-juss hybrid!
 * 
 * @author PETO
 *
 * @since 1.3.2
 */
public class JsonSerializer extends JussSerializer 
{
	public static final Registry<DataParser> JSON_PARSERS = new Registry<>(new VariableConverter(true), new StringConverter(), new ObjectConverter(true), new NumberConverter(), new BooleanConverter(), new CharacterConverter(), new NullConverter(), new SerializableBase64Converter());
	
	/**
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.3.2
	 */
	public JsonSerializer(Object... values) 
	{
		this(null, values);
	}
	
	/**
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.3.2
	 */
	public JsonSerializer(Map<String, ?> variablesMap, Object... values) 
	{
		this(variablesMap, values == null ? null : new ArrayList<>(Arrays.asList(values)));
	}

	/**
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.3.2
	 */
	public JsonSerializer(Map<String, ?> variablesMap, Collection<?> values) 
	{
		this(JSON_PARSERS.clone(), variablesMap, values);
	}
	
	/**
	 * @param parsers | Registry of parsers to use!
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.3.2
	 */
	public JsonSerializer(Registry<DataParser> parsers, Map<String, ?> variablesMap, Collection<?> values) 
	{
		this(parsers, SerializationProtocol.REGISTRY.clone(), variablesMap, values, null);
	}
	
	/**
	 * @param parsers | Registry of parsers to use!
	 * @param protocols | Registry of protocols to use!
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * @param parent | Parent of this scope.
	 *
	 * @since 1.3.2
	 */
	public JsonSerializer(Registry<DataParser> parsers, ProtocolRegistry protocols, Map<String, ?> variablesMap, Collection<?> values, Scope parent) 
	{
		super(parsers, protocols, variablesMap, values, parent);
	}
	
	@Override
	public <T> String Var(String name, T value, boolean isValue) 
	{
		return Code((isValue ? "$\"" : "\"") + name + "\" = " + DataConverter.objToString(getParsers(), value, 0, 0, this, getProtocols(), isGenerateComments()) + (generateComments ? ", //Object of " + value.getClass().getName() + ": \"" + value + "\" inserted manually! Stored by \"" + name + "\" variable!" : ""));
	}
	
	@Override
	public Object put(String variableName, Object variableValue) 
	{
		if (Serializer.isOneOf(variableName.charAt(0), '"', '\'') && Serializer.isOneOf(variableName.charAt(variableName.length()-1), '"', '\''))
			variableName = variableName.substring(1, variableName.length()-1);
		return super.put(variableName, variableValue);
	}
	
	@Override
	public Scope LoadFrom(Reader reader, Object... formatArgs) 
	{
		Scope sc = super.LoadFrom(reader, formatArgs);
		if (sc.valuesCount() == 1 && sc.variablesCount() <= 0 && sc.get(0) instanceof Scope)
			return sc.getScope(0);
		return sc;
	}
	
	@Override
	public <A extends Appendable> A SerializeTo(A source, Object... args) throws IOException 
	{
		int tabs = 0;
		if (args.length > 0 && args[0] instanceof Integer)
			tabs = (int) args[0];
		
		if (tabs == 0 && !(valuesCount() == 1 && variablesCount() <= 0 && get(0) instanceof Scope))
		{
			JussSerializer scope = enptyClone(null);
			scope.add(this);
			return scope.SerializeTo(source, args);
		}
		return super.SerializeTo(source, args);
	}
	
	@Override
	public Registry<DataParser> getParsers() 
	{
		return parsers != null ? parsers : (parsers = JSON_PARSERS.clone());
	}
	
	/**
	 * This should append serializedVar into source based on arguments, add separator and return source!
	 * 
	 * @since 1.3.2
	 */
	@Override
	protected Appendable appandVar(Appendable source, CharSequence serializedVar, Entry<String, Object> var, int tabs, boolean isLast) throws IOException
	{
		source.append(multilpy('\t', tabs)).append(serializedVar);
		if (isLast)
			return source;
		return source.append(',');
	}
	
	/**
	 * This should append serializedVal into source based on arguments, add separator and return source!
	 * 
	 * @since 1.3.2
	 */
	@Override
	protected Appendable appandVal(Appendable source, CharSequence serializedVal, Object value, int tabs, boolean isLast) throws IOException
	{
		source.append(multilpy('\t', tabs)).append(serializedVal);
		if (isLast || indexOfNotInObj(serializedVal, '/') != -1)
			return source;
		return source.append(',');
	}
	
	/**
	 * @param jsonSerializer | JsonSerializer to create {@link JussSerializer} from!
	 * 
	 * @return JussSerializer created from JsonSerializer, all values and variables will remain intact!
	 * 
	 * @since 1.3.2
	 */
	public static JsonSerializer fromJussSerializer(JussSerializer jussSerializer)
	{
		if (jussSerializer instanceof JsonSerializer)
			return (JsonSerializer) jussSerializer;
		jussSerializer = new JsonSerializer((jussSerializer = (JussSerializer) jussSerializer.transformToScope()).variables(), jussSerializer.values());
		jussSerializer.parent = jussSerializer.getParent();
		return (JsonSerializer) jussSerializer;
	}
}
