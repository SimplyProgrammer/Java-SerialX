package org.ugp.serialx;

import java.util.ArrayList;
import java.util.List;

import org.ugp.serialx.converters.DataConverter;
import org.ugp.serialx.converters.DataParser;

/**
 * This parser maintains list of {@link Imports#IMPORTS} represented as {@link Import}s. Where are registered imports imported by user as well as temporary imports that are parsed! Result of parsing will be always added to imports list and {@link DataParser#VOID} will be returned!
 * Parsing example: <code>import java.util.ArrayList</code> will add temporary {@link Import} of java.util.ArrayList or <code>java.lang.String => Word</code> will import java.lang.String as Word!
 * Imports will be converted to string just by calling toString!
 * 
 * @author PETO
 *
 * @since 1.3.0
 */
public class Imports implements DataConverter 
{	
	/**
	 * List of registered imports!
	 * 
	 * @since 1.3.0
	 */
	public static final List<Import> IMPORTS = new ArrayList<>();
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args) 
	{
		int index;
		if (str.startsWith("import "))
		{
			try 
			{
				if ((str = str.substring(7).trim()).indexOf("=>") > -1)
					return parse(myHomeRegistry, str);
				IMPORTS.add(new Import(forName(str)).tmpInstance());
			} 
			catch (ClassNotFoundException e) 
			{
				System.err.println("Unable to import " + str + " because there is no such a class!");
			}
			return VOID;
		}
		else if ((index = (str = str.trim()).indexOf("=>")) > -1)
		{
			try 
			{
				IMPORTS.add(new Import(forName(str.substring(0, index).trim()), str.substring(index+2).trim()).tmpInstance());
			} 
			catch (ClassNotFoundException e) 
			{
				System.err.println("Unable to import " + str.substring(0, index).trim() + " because there is no such a class!");
			}
			return VOID;
		}
		return CONTINUE;
	}

	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object obj, Object... args) 
	{
		if (obj instanceof Import)
		{
			IMPORTS.add(((Import) obj).tmpInstance());
			return obj.toString();
		}
		return CONTINUE;
	}
	
	@Override
	public String getDescription(Registry<DataParser> myHomeRegistry, Object objToDescribe, Object... argsUsedConvert) 
	{
		return "Import of " + ((Import) objToDescribe).getCls() + " as " + ((Import) objToDescribe).getClsAlias();
	}
	
	/**
	 * @param cls | Class to get alias for!
	 * 
	 * @return Alias of class picked from {@link Imports#IMPORTS} or name of class if there is no import for this class!
	 * 
	 * @since 1.3.0
	 */
	public static String getAliasFor(Class<?> cls)
	{
		for (int i = IMPORTS.size() - 1; i >= 0; i--)
		{
			Import imp = IMPORTS.get(i);
			if (imp.equals(cls))
				return imp.getClsAlias();
		}
		return cls.getName();
	}
	
	/**
	 * @param alias | Alias of class to obtain!
	 * 
	 * @return Class with inserted alias picked from {@link Imports#IMPORTS} or null if there is no import with required alias!
	 */
	public static Class<?> getClassFor(String alias)
	{
		for (int i = IMPORTS.size() - 1; i >= 0; i--)
		{
			Import imp = IMPORTS.get(i);
			if (imp.equals(alias))
				return imp.getCls();
		}
		return null;
	}
	
	/**
	 * This will remove all temporary imports from {@link Imports#IMPORTS}!
	 * 
	 * @since 1.3.0
	 */
	public static void clearTmps()
	{
		for (Import imp : new ArrayList<>(IMPORTS))
			if (imp.isTmp)
				IMPORTS.remove(imp);
	}

	/**
	 * @param aliasOrName | Alias of class or its full name!
     * 
	 * @return Class with inserted alias picked from {@link Imports#IMPORTS} similar to {@link Imports#getClassFor(String)} but this will also search via {@link Class#forName(String, boolean, ClassLoader)} if there is no import with required alias!
	 * 
	 * @throws ClassNotFoundException when {@link Class#forName(String, boolean, ClassLoader)} throws!
	 * 
	 * @since 1.3.0
	 */
	public static Class<?> forName(String aliasOrName) throws ClassNotFoundException
	{
		return forName(aliasOrName, true, Imports.class.getClassLoader());
	}
	
	/**
	 * @param aliasOrName | Alias of class or its full name!
	 * @param initialize | If true the class will be initialized. See Section 12.4 of <i>The Java Language Specification</i>.
     * @param loader | Class loader from which the class must be loaded.
     * 
	 * @return Class with inserted alias picked from {@link Imports#IMPORTS} similar to {@link Imports#getClassFor(String)} but this will also search via {@link Class#forName(String, boolean, ClassLoader)} if there is no import with required alias!
	 * If there are no dots in required alias and alias is not imported then null will be returned!
	 * 
	 * @throws ClassNotFoundException when {@link Class#forName(String, boolean, ClassLoader)} throws!
	 * 
	 * @since 1.3.0
	 */
	public static Class<?> forName(String aliasOrName, boolean initialize, ClassLoader loader) throws ClassNotFoundException
	{
		Class<?> cls = getClassFor(aliasOrName);
		if (cls != null)
			return cls;
		if (aliasOrName.indexOf('.') > 0)
			return Class.forName(aliasOrName, initialize, loader);
		/*try
		{
			return Class.forName("java.lang."+aliasOrName, initialize, loader);
		}
		catch (Exception e)
		{
			return null;
		}*/
		return null;
	}
	
	/**
	 * This class is used to represent import. It stores target class of import and its alias!
	 * 
	 * @author PETO
	 *
	 * @since 1.3.0
	 */
	public static class Import
	{
		protected final Class<?> cls;
		protected final String alias;
		protected final boolean isTmp;
		
		/**
		 * @param cls | Class to create import for! Alias of this class will be its simple name!
		 * 
		 * @since 1.3.0
		 */
		public Import(Class<?> cls) 
		{
			this(cls, cls.getSimpleName());
		}
		
		/**
		 * @param cls | Class to create import for! 
		 * @param alias | Alias of class!
		 * 
		 * @since 1.3.0
		 */
		public Import(Class<?> cls, String alias) 
		{
			this(cls, alias, false);
		}
		
		/**
		 * @param cls | Class to create import for! 
		 * @param alias | Alias of class!
		 * @param isTmp | If true this import is marked as temporary!
		 * 
		 * @since 1.3.0
		 */
		protected Import(Class<?> cls, String alias, boolean isTmp) 
		{
			this.cls = cls;
			this.alias = alias;
			this.isTmp = isTmp;
		}
		
		@Override
		public String toString() 
		{
			if (getCls().getSimpleName().equals(getClsAlias()))
				return "import " + getCls().getName();
			return getCls().getName() + " => " + getClsAlias();
		}
		
		@Override
		public boolean equals(Object obj) 
		{
			if (obj instanceof String)
				return getClsAlias().equals(obj);
			else if (obj instanceof Class)
				return getCls().equals(obj);
			return super.equals(obj);
		}
		
		/**
		 * @return True if this import is temporary!
		 * 
		 * @since 1.3.0
		 * 
		 * @see Imports#clearTmps()
		 */
		public Import tmpInstance()
		{
			return new Import(getCls(), getClsAlias(), true);
		}
		
		/**
		 * @return Class of this import!
		 * 
		 * @since 1.3.0
		 */
		public Class<?> getCls() 
		{
			return cls;
		}

		/**
		 * @return Alias for class!
		 * 
		 * @since 1.3.0
		 */
		public String getClsAlias() 
		{
			return alias;
		}
	}
}
