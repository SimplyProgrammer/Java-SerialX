package org.ugp.serialx.protocols;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.ugp.serialx.Scope;
import org.ugp.serialx.Serializer;

/**
 * This is automatic protocol that will automatically serialize every or selected field in object that has valid and public getter and setter!
 * This protocol is applicable on anything you want however condition of use is absence of final field otherwise {@link AutoProtocol#createBlankInstance(Class)} should be overridden. ALso you should {@link AutoProtocol#createBlankInstance(Class)} when you object is to complex!
 * 
 * @author PETO
 *
 * @param <T> | Generic type of object to use protocol for.
 * 
 * @since 1.2.2
 */
public class AutoProtocol<T> extends SerializationProtocol<T> 
{
	protected final Class<T> applicableFor;
	protected List<PropertyDescriptor> variables = new ArrayList<>();
	protected boolean useScope;
	
	/**
	 * @param applicableFor | Class that can be serialized using this protocol.
	 * @param fieldNamesToSerialize | Names of fields to serialize, if empty array is put there then all fields with public and valid getters and setters will be serialized!
	 * 
	 * @throws IntrospectionException when there are no field with valid and public getters and setters.
	 * 
	 * @since 1.2.2
	 */
	public AutoProtocol(Class<T> applicableFor, String... fieldNamesToSerialize) throws IntrospectionException
	{
		this(applicableFor, false, fieldNamesToSerialize);
	}
	
	/**
	 * @param applicableFor | Class that can be serialized using this protocol.
	 * @param useScope | If true, objects will be serialized using scope which is longer but more readable!
	 * @param fieldNamesToSerialize | Names of fields to serialize, if empty array is put there then all fields with public and valid getters and setters will be serialized!
	 * 
	 * @throws IntrospectionException when there are no field with valid and public getters and setters.
	 * 
	 * @since 1.3.2
	 */
	public AutoProtocol(Class<T> applicableFor, boolean useScope, String... fieldNamesToSerialize) throws IntrospectionException
	{
		this.applicableFor = applicableFor;
		setUseScope(useScope);
		if (fieldNamesToSerialize.length <= 0)
		{
			if ((variables = getPropertyDescriptorsOf(applicableFor)).isEmpty())
				throw new IntrospectionException("No fields with valid and public getters and setters to use in " + applicableFor.getSimpleName());
		}
		else
		{
			for (int i = 0; i < fieldNamesToSerialize.length; i++) 
				variables.add(new PropertyDescriptor(fieldNamesToSerialize[i], applicableFor));
		}
	}
	
	/**
	 * @param objectClass | Class to create new instance of!
	 * 
	 * @return New blank instance of required class! When not override, it returns {@link Serializer#Instantiate(objectClass)} 
	 * 
	 * @throws Exception if any exception occurs (based on implementation).
	 * 
	 * @since 1.2.2
	 */
	public T createBlankInstance(Class<? extends T> objectClass) throws Exception
	{
		return Serializer.Instantiate(objectClass);
	}
	
	@Override
	public Object[] serialize(T object)
	{
		try
		{
			if (isUseScope())
			{
				Scope scope = new Scope();
				for (PropertyDescriptor var : variables) 
					scope.put(var.getName(), var.getReadMethod().invoke(object));
				return new Object[] {scope};
			}
			else
			{
				Object[] args = new Object[variables.size()];
				for (int i = 0; i < variables.size(); i++) 
					args[i] = variables.get(i).getReadMethod().invoke(object);
				return args;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public T unserialize(Class<? extends T> objectClass, Object... args) throws Exception 
	{
		T obj = createBlankInstance(objectClass);
		if (isUseScope() && args.length == 1 && args[0] instanceof Scope)
		{
			Scope sc = (Scope) args[0];
			for (Entry<String, Object> var : sc.varEntrySet())
			{
				PropertyDescriptor varDesc = getVariablesDescriptor(var.getKey());
				if (varDesc != null)
					varDesc.getWriteMethod().invoke(obj, var.getValue());
			}
		}
		else
			for (int i = 0; i < variables.size(); i++) 
				variables.get(i).getWriteMethod().invoke(obj, args[i]);
		return obj;
	}
	
	/**
	 * @param variableName | Name of variable!
	 * 
	 * @return PropertyDescriptor of variable with name or null if this protocols can't use it!
	 * 
	 * @since 1.3.2
	 */
	public PropertyDescriptor getVariablesDescriptor(String variableName)
	{
		for (PropertyDescriptor var : variables) 
			if (var.getName().equals(variableName))
				return var;
		return null;
	}

	@Override
	public Class<? extends T> applicableFor() 
	{
		return applicableFor;
	}

	/**
	 * @return If true, objects will be serialized using scope which is longer but more readable!
	 * 
	 * @since 1.3.2
	 */
	public boolean isUseScope() 
	{
		return useScope;
	}

	/**
	 * @param useScope | If true, objects will be serialized using scope which is longer but more readable!
	 * 
	 * @since 1.3.2
	 */
	public void setUseScope(boolean useScope) 
	{
		this.useScope = useScope;
	}
	
	/**
	 * @param cls | Class to inspect!
	 * 
	 * @return List of {@link PropertyDescriptor}s of cls! Only descriptors of variables that have valid and public getter and setter will be returned!
	 * 
	 * @see PropertyDescriptor
	 * 
	 * @since 1.3.2
	 */
	public static List<PropertyDescriptor> getPropertyDescriptorsOf(Class<?> cls)
	{
		List<PropertyDescriptor> variables = new ArrayList<>();
		
        for (Class<?> c = cls; c != Object.class; c = c.getSuperclass())
			for (Field field : c.getDeclaredFields())
				if (!Modifier.isStatic(field.getModifiers()) && !Modifier.isFinal(field.getModifiers()))
					try
					{
						variables.add(new PropertyDescriptor(field.getName(), cls));
					}
					catch (Exception e)
					{}
        
        return variables;
	}
}
