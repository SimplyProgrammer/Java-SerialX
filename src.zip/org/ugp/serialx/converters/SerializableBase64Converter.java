package org.ugp.serialx.converters;

import static org.ugp.serialx.Serializer.fastReplace;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;

import org.ugp.serialx.Registry;
import org.ugp.serialx.protocols.SerializationProtocol;

/**
 * This converter is capable of converting {@link String}.
 * Its case sensitive!
 * <br>
 * <br>
 * Table of sample string <--> object conversions:
	<style>
		table, th, td 
		{
		  border: 1px solid gray;
		}
	</style>
	<table>
		<tr>
		    <th>String</th>
		    <th>Object</th> 
		</tr>
		<tr>
		    <td>#rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeA--</td>
		    <td>new ArrayList()</td>
	  	</tr>
	  	<tr>
		    <td>#rO0ABXVyAAJbSU26YCZ26rKlAgAAeHAAAAADAAAABQAAAAUAAAAF</td>
		    <td>new int[] {5, 5, 5}</td>
	  	</tr>
	</table>
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class SerializableBase64Converter implements DataConverter 
{
	/**
	 * Set this on true to force program to use SerializationProtocol also on java.io.Serializable objects.
	 * Doing this also might take less memory space then using classic java.io.Serializable.
	 * In some cases, java Serialization can be more effective than protocols sometimes not! You should try which gives you the best result, then you can also deactivate certain protocols that are less effective than Java serialization.
	 * For example for long strings, classic Java serialization is better than protocol, it will take less memory storage space, but performance is almost always far slower!<br>
	 * Note: Whole concept of SerialX API is about avoiding classic Java serialization from many reasons so you most likely want this on true! Also protocol will be almost certainly faster classic serialization!
	 * 
	 * @since 1.0.0 (moved to {@link SerializableBase64Converter} since 1.3.0)
	 */
	public static boolean useProtocolIfCan = true;
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String arg, Object... args) 
	{
		if (arg.startsWith("#") || arg.startsWith("r"))
		{
			try
			{
				return UnserializeClassis(arg = fastReplace(arg, "#", ""));
			}
			catch (Exception e) 
			{
				System.err.println("Looks like there appear some problems with unserializing some object, the instance of java.io.Serializable from string \"" + arg + "\"! This string is most likely corrupted! See error below:");
				e.printStackTrace();
				return null;
			}
		}
		return CONTINUE;
	}

	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object arg, Object... args) 
	{
		if (arg instanceof Serializable && (!useProtocolIfCan || SerializationProtocol.REGISTRY.GetProtocolFor(arg) == null))
			try
			{
				return "#"+SerializeClassic((Serializable) arg);
			}
			catch (Exception e)
			{
				System.err.println("Looks like there appear some problems with serializing \"" + arg + "\", the instance of java.io.Serializable. This could happen when certain object contains non-transient unserializable objects. Use custom valid protocol for serializing \"" + arg + "\" might solve the problem!");
				e.printStackTrace();
				return null;
			}
		return CONTINUE;
	}
	
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object obj, Object... argsUsedConvert) 
	{
		return new StringBuilder("Object of ").append(obj.getClass().getName()).append(": \"").append(obj).append("\" serialized using classic Base64 java.io.Serializable!");
	}
	
	/**
	 * @param objStr | String to unserialize by classic Java serialization.
	 * Note: Backslashes will be replaced by regular slashes and dashes with Base64 padding due to compatibility with JUSS syntax.<br>
	 * 
	 * @return Unsrialized object.
	 * 
	 * @throws IOException - if an I/O error occurs while reading stream header.
	 * @throws ClassNotFoundException - Class of a serialized object cannot be found. 
	 * 
	 * @see java.util.Base64
	 * 
	 * @since 1.0.0 (moved to {@link SerializableBase64Converter} since 1.3.0)
	 */
	public static Object UnserializeClassis(String objStr) throws Exception
	{
        return new ObjectInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(fastReplace(fastReplace(objStr, "%", "/"), "-", "=")))).readObject();
	}
	
	/**
	 * @param obj | Object to serialize using classic Java serialization.
 	 * Note: Slash will be replaced by back slash and Base64 padding with dash due to prevent conflict with JUSS syntax!
	 * 
	 * @return String with serialized object.
	 * 
	 * @throws Exception - if an I/O error occurs while writing stream header
	 * 
	 * @see java.lang.Base64
	 * 
	 * @since 1.0.0 (moved to {@link SerializableBase64Converter} since 1.3.0)
	 */
	public static String SerializeClassic(Serializable obj) throws Exception
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);

        oos.writeObject(obj);
        oos.close();
        return fastReplace(fastReplace(Base64.getEncoder().encodeToString(baos.toByteArray()), "/", "%"), "=", "-"); 
	}
}
