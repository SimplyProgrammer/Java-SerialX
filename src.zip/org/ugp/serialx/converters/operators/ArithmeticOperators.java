package org.ugp.serialx.converters.operators;

import static org.ugp.serialx.Serializer.fastReplace;
import static org.ugp.serialx.Serializer.isOneOf;
import static org.ugp.serialx.converters.DataParser.parseObj;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.ugp.serialx.Registry;
import org.ugp.serialx.Scope;
import org.ugp.serialx.Serializer;
import org.ugp.serialx.converters.ArrayConverter;
import org.ugp.serialx.converters.DataParser;

/**
 * This parser provides arithmetics operators to evaluate mathematical expressions such as <code>5 * 2 +-- 2 / 2 ** 2 % 4</code> = 10!
 * 
 * @author PETO
 *
 * @since 1.3.0
 */
public class ArithmeticOperators implements DataParser 
{
	protected String[] priority1Oprs = {"*", "*-", "/", "/-", "%"}, priority2Oprs = {"**", "**-"};
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String s, Object... args) 
	{
		if (s.length() > 2 && isExpression(s, '+', '-', '*', '/', '%'))
			return eval(myHomeRegistry, s, args);
		return CONTINUE;
	}
	
	/**
	 * @return Result of evaluated expression that was inserted! For instance 5 + 5, result 10!
	 * 
	 * @since 1.3.0
	 */
	protected Object eval(Registry<DataParser> registryForParsers, String expr, Object... argsForParsers)
	{
		while (expr.contains("++") || expr.contains("--") || expr.contains("+-") || expr.contains("-+"))
			expr = fastReplace(fastReplace(fastReplace(fastReplace(expr, "-+", "-"), "+-", "-"), "--", "+"), "++", "+");

		List<Object> cofs = getTerm(expr, false, '+', '-', '*', '/', '%'); 

		if (cofs.size() <= 1)
			return CONTINUE;
		List<Object> oprs = getTerm(expr, true, '+', '-', '*', '/', '%'); 

		Object cof1 = null, cof2 = null;
		String opr = null;
		try 
		{
			for (int i = 0, index = -1, orderIndex = 0; cofs.size() + oprs.size() > 1; index = -1, i++) 
			{
				for (String adept : priority1Oprs)
					if ((orderIndex = oprs.indexOf(adept)) > -1 && (index == -1 || orderIndex < index))
						index = orderIndex;
				for (String adept : priority2Oprs)
					if ((orderIndex = oprs.indexOf(adept)) > -1)
						index = orderIndex;

				cof1 = cofs.get(index = index < 0 ? 0 : index);
				if (cof1 instanceof String)
					cof1 = parseObj(registryForParsers, cof1.toString().trim(), i > 0, new Class[] {getClass(), ArrayConverter.class}, argsForParsers);
				cof1 = cof1 instanceof ResultWrapper ? ((ResultWrapper) cof1).obj : cof1;
	
			    cof2 = cofs.remove(index + 1);
			    if (cof2 instanceof String)
			    	cof2 = parseObj(registryForParsers, cof2.toString().trim(), i > 0, new Class[] {getClass()}, argsForParsers);
			    cof2 = cof2 instanceof ResultWrapper ? ((ResultWrapper) cof2).obj : cof2;
			    
				opr = oprs.remove(index).toString();
				if (opr.charAt(0) == '+')
					cofs.set(index, new ResultWrapper(addOperator(cof1, cof2)));
				else if (opr.charAt(0) == '-')
					cofs.set(index, new ResultWrapper(subOperator(cof1, cof2)));
				else if (opr.startsWith("**"))
					cofs.set(index, new ResultWrapper(powOperator(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '*')
					cofs.set(index, new ResultWrapper(multOperator(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '/')
					cofs.set(index, new ResultWrapper(divOperator(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '%')
					cofs.set(index, new ResultWrapper(modOperator(cof1, cof2)));
			}
		}
		catch (ClassCastException ex)
		{
			System.err.println("Arithmetic operator " + opr + " is undefined between " + cof1.getClass().getName() + " and " + cof2.getClass().getName() + "!");
			return null;
		}
		
		Object finalResult = cofs.get(0);
		return finalResult instanceof ResultWrapper ? ((ResultWrapper) finalResult).obj : finalResult;
	}
	
	/** 
	 * @return Addition of cof and cof2 (cof + cof2) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object addOperator(Object cof, Object cof2)
	{
		return add(toNum(cof), cof instanceof String ? cof2 : toNum(cof2));
	}
	
	/** 
	 * @return Subtraction of cof and cof2 (cof + cof2) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object subOperator(Object cof, Object cof2)
	{
		return sub(toNum(cof), toNum(cof2));
	}
	
	/** 
	 * @return Multiplication of cof and cof2 multiplied by sign (cof * cof2 * sign) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object multOperator(Object cof, Object cof2, int sign)
	{
		return mult(toNum(cof), toNum(cof2), sign);
	}
	
	/** 
	 * @return Division of cof and cof2 multiplied by sign (cof / cof2 * sign) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object divOperator(Object cof, Object cof2, int sign)
	{
		return div(toNum(cof), toNum(cof2), sign);
	}
	
	/** 
	 * @return Modulation of cod and cof2 (cof % cof2) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object modOperator(Object cof, Object cof2)
	{
		return mod(toNum(cof), toNum(cof2));
	}
	
	/** 
	 * @return Cof powered by cof2 multiplied by sign (Math.pow(cof, cof2 * sign)) supposed to be returned! 
	 * 
	 * @since 1.3.2
	 */
	public Object powOperator(Object cof, Object cof2, int sign)
	{
		return pow(toNum(cof), toNum(cof2), sign);
	}
	
	/**
	 * @return Addition of cof and cof2 (cof + cof2)! 
	 * 
	 * @since 1.3.0
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object add(Object cof, Object cof2)
	{
		if (!(cof instanceof Number) || !(cof2 instanceof Number))
		{
			//System.out.println(cof + "+" + cof2);
			
			if (cof.getClass().isArray())
				return ArrayConverter.mergeArrays(cof, cof2);
			else if (cof instanceof Collection)
			{
				if (cof2 instanceof Collection)
					((Collection) cof).addAll(((Collection) cof2));
				else if (cof2.getClass().isArray())
					((Collection) cof).addAll(Arrays.asList(ArrayConverter.fromAmbiguous(cof2)));
				else 
					((Collection) cof).add(cof2);
				return cof;
			}
			else if (cof instanceof Scope)
			{
				if (cof2 instanceof Scope)
					((Scope) cof).addAll(((Scope) cof2));
				else if (cof2 instanceof Collection)
					((Scope) cof).addAll((Collection) cof2);
				else if (cof2.getClass().isArray())
					((Scope) cof).addAll(ArrayConverter.fromAmbiguous(cof2));
				else 
					((Scope) cof).add(cof2);
				return cof;
			}
			return toString(cof) + toString(cof2);
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() + ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() + ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() + ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() + ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() + ((Number) cof2).doubleValue();
		return toString(cof) + toString(cof2);
	}
	
	/**
	 * @return Subtraction of cof and cof2 (cof - cof2)!
	 * 
	 * @since 1.3.0
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object sub(Object cof, Object cof2)
	{
		if (!(cof instanceof Number) || !(cof2 instanceof Number))
		{
			if (cof instanceof Collection)
			{
				if (cof2 instanceof Collection)
					((Collection) cof).removeAll(((Collection) cof2));
				else if (cof2.getClass().isArray())
					((Collection) cof).removeAll(Arrays.asList(ArrayConverter.fromAmbiguous(cof2)));
				else 
					((Collection) cof).remove(cof2);
				return cof;
			}
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() - ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() - ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() - ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() - ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() - ((Number) cof2).doubleValue();
		return null;
	}
	
	/**
	 * @return Multiplication of cof and cof2 multiplied by sign (cof * cof2 * sign)!
	 * 
	 * @since 1.3.0
	 */
	public static Object mult(Object cof, Object cof2, int sign)
	{
		if (cof2 instanceof Number && !(cof instanceof Number))
		{
			String orig = cof.toString(), now = "";
			for (int i = 0; i < ((Number) cof2).intValue() * sign; i++) 
				now += orig;
			return now;
		}
		else if (cof instanceof Number && !(cof2 instanceof Number))
		{
			String orig = cof2.toString(), now = "";
			for (int i = 0; i < ((Number) cof).intValue() * sign; i++) 
				now += orig;
			return now;
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() * ((Number) cof2).doubleValue() * sign;
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() * ((Number) cof2).floatValue() * sign;
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() * ((Number) cof2).intValue() * sign;
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() * ((Number) cof2).longValue() * sign;
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() * ((Number) cof2).doubleValue() * sign;
		return null;	
	}
	
	/**
	 * @return Division of cof and cof2 multiplied by sign (cof / cof2 * sign)!
	 * 
	 * @since 1.3.0
	 */
	public static Object div(Object cof, Object cof2, int sign)
	{
		if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() / ((Number) cof2).doubleValue() * sign;
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() / ((Number) cof2).floatValue() * sign;
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() / ((Number) cof2).intValue() * sign;
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() / ((Number) cof2).longValue() * sign;
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() / ((Number) cof2).doubleValue() * sign;
		return null;	
	}
	
	/**
	 * @return Modulation of cod and cof2 (cof % cof2)!
	 * 
	 * @since 1.3.0
	 */
	public static Object mod(Object cof, Object cof2)
	{
		if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() % ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() % ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() % ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() % ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() % ((Number) cof2).doubleValue();
		return null;	
	}
	
	/**
	 * @return Cof powered by cof2 multiplied by sign (Math.pow(cof, cof2 * sign))!
	 * 
	 * @since 1.3.0
	 */
	public static Object pow(Object cof, Object cof2, int sign)
	{
		if (cof instanceof Number && cof2 instanceof Number)
		{
			double pow = Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
			if (pow > Long.MAX_VALUE || pow < Long.MIN_VALUE || cof instanceof Double || cof2 instanceof Double)
				return pow;
			else if (pow <= Float.MAX_VALUE && pow >= Float.MIN_VALUE && (cof instanceof Float || cof2 instanceof Float))
				return (float) pow;
			if (pow > Integer.MAX_VALUE || pow < Integer.MIN_VALUE || cof instanceof Long || cof2 instanceof Long)
				return (long) pow;
			else if (cof instanceof Integer || cof2 instanceof Integer)
				return (int) pow;
		}
		return null;	
	}
	
	/**
	 * 
	 * @param str | String to split!
	 * @param operatos | If true, list of spited operators will be returned otherwise terms split after each operator.
	 * @param oprs | Operators to use as a splitters.
	 * 
	 * @return List of terms splitted according to inserted arguments! For example <code>getTerm("5 + 6", true, '+')</code> will return <code>[+]</code>, while <code>getTerm("5 + 6", false, '+')</code> will return <code>[5, 6]</code>! 
	 *
	 * @since 1.3.0
	 */
	public static List<Object> getTerm(String str, boolean operators, char... oprs)
	{
		List<Object> ret = new ArrayList<>();

		StringBuilder sb = new StringBuilder();
		for (int i = 0, len = str.length(), quote = 0, brackets = 0; i < len; i++) 
		{
			char ch = str.charAt(i);
			if (ch == '\"')
				quote++;
			else if (ch == '{' || ch == '[')
				brackets++;
			else if (ch == '}' || ch == ']')
				brackets--;
			
			boolean notString = quote % 2 == 0 && brackets == 0;
			if (!operators && !notString)
				sb.append(ch);
			else if (notString)
			{
				if (isOneOf(ch, oprs) == operators && i > 0 || (i == 0 && !operators))
					sb.append(ch);
				else if (sb.length() > 0)
				{
					String s = sb.toString().trim();
					if (!s.isEmpty())
						ret.add(s);
					sb = new StringBuilder();
				}
			}
		}
		
		if (sb.length() > 0)
		{
			String s = sb.toString().trim();
			if (!s.isEmpty())
				ret.add(s);
		}
		return ret;
	}
	
	/**
	 * @param str | String that might be an expression!
	 * @param operators | Operators that str must have!
	 * 
	 * @return True if inserted string is expression with any coefficients splitted by operators!
	 * 
	 * @since 1.3.2
	 */
	public static boolean isExpression(CharSequence str, char... operators)
	{
		int hasOpr = -1;
		for (int i = 0, len = str.length(), oldCh = 0, isCof = 0, quote = 0, brackets = 0; i < len; i++)
		{
			char ch = str.charAt(i);
			if (ch > 32)
			{
				if (ch == '\"')
					quote++;
				else if (quote % 2 == 0)
				{
					if (ch == '{' || ch == '[')
						brackets++;
					else if (ch == '}' || ch == ']')
						brackets--;
					else if (brackets == 0)
					{
						if (Serializer.isOneOf(ch, operators))
							hasOpr = isCof = 0;
						else if (oldCh <= 32 && isCof == 1)
							return false;
						else
							isCof = 1;
					}
				}
			}
			oldCh = ch;
		}
		return hasOpr == 0;
	}
	
	/**
	 * @return null -> 0, bool ? 1 : 0
	 * 
	 * @since 1.3.0
	 */
	public static Object toNum(Object obj)
	{
		if (obj == null)
			return 0;
		else if (obj instanceof Boolean)
			return (boolean) obj ? 1 : 0;
		else if (obj instanceof Character)
			return (int) (char) obj;
		return obj; 
	}
	
	/**
	 * @return "null" if null and else obj.toString();
	 * 
	 * @since 1.3.0
	 */
	public static String toString(Object obj)
	{
		return obj == null ? "null" : obj.toString();
	}
	
	/**
	 * Used internally by {@link ArithmeticOperators} to wrap result of evaluation!
	 * 
	 * @author PET
	 *
	 * @since 1.3.0
	 */
	protected static class ResultWrapper
	{
		public final Object obj;
		
		public ResultWrapper(Object obj) 
		{
			this.obj = obj;
		}
		
		@Override
		public String toString() 
		{
			return obj.toString();
		}
	}
}
