package org.ugp.serialx.converters;

import static org.ugp.serialx.Serializer.Clone;
import static org.ugp.serialx.Serializer.contains;
import static org.ugp.serialx.Serializer.fastReplace;
import static org.ugp.serialx.Serializer.isOneOf;
import static org.ugp.serialx.Serializer.multilpy;
import static org.ugp.serialx.Serializer.splitValues;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import org.ugp.serialx.Registry;
import org.ugp.serialx.Scope;
import org.ugp.serialx.Serializer.NULL;

/**
 * This converter is capable of converting {@link Map.Entry} and reading variables from {@link Scope} via "$"!
 * {@link VariableConverter#parse(String, Object...)} required one additional Scope argument in args... argument!
 * Its case insensitive!<br>
 * Exact outputs of this converter are based on inserted scope!
 * 
 * @author PETO
 *	
 * @since 1.3.0
 */
public class VariableConverter implements DataConverter
{
	protected boolean jsonStyle;
	
	public VariableConverter() 
	{
		this(false);
	}
	
	/**
	 * @param jsonStyle | If true, this converter will be using Json style of variables ("key" : value)!
	 * 
	 * @since 1.3.2
	 */
	public VariableConverter(boolean jsonStyle) 
	{
		setJsonStyle(jsonStyle);
	}
	
	/**
	 * Raw example of variable entry this converter can convert!
	 * 
	 * @since 1.3.0 
	 */
	public static final Entry<String, Object> RAW_VAR_ENTRY = new Entry<String, Object>() 
	{
		@Override
		public String getKey() 
		{
			return "";
		}

		@Override
		public Object getValue()
		{
			return null;
		}

		@Override
		public Object setValue(Object value) 
		{
			return null;
		}
	};
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String arg, Object... args) 
	{
		if (args.length > 0 && arg.length() > 0 && args[0] instanceof Scope)
		{
			Scope parent = (Scope) args[0];
			if (isVarAssignment(arg))
			{
				String[] enrty;
				if (isOneOf(arg.charAt(0), '=', ':'))
					enrty = new String[] {"", arg.substring(1).trim()};
				else
					enrty = splitValues(arg, 0, false, '=', ':');

				Object obj = null;
				String objString = enrty[enrty.length-1];
				if (enrty.length > 1 && !objString.isEmpty())
				{
					obj = NULL.toOopNull(DataParser.parseObj(myHomeRegistry, objString, args));
				}
				
				for (int i = 0; i < enrty.length-1; i++)
				{
					if (contains(enrty[i] = enrty[i].trim(), ' '))
						System.err.println("Variable name \"" + enrty[i] + "\" is invalid, blank characters are not allowed!");
					else
					{
						if ((enrty[i] = fastReplace(enrty[i], "$", "")).indexOf('.') > -1)
						{
							String[] tree = splitValues(enrty[i], '.');
							Scope sc = parent.getScope(Arrays.copyOfRange(tree, 0, tree.length-1));
							if (sc != null)
							{
								if (obj == VOID)
									sc.variables().remove(enrty[i]);
								else
									sc.put(tree[tree.length-1], obj);
							}
							else
								System.err.println("Variable \"" + tree[tree.length-2] +"\" was not declared as scope in its parent so variable \"" + tree[tree.length-1] +"\" cant be set to \"" + obj + "\"!");
						}
						else if (obj == VOID)
							parent.variables().remove(enrty[i]);
						else
							parent.put(enrty[i], obj);
					}
				}
				if (arg.charAt(0) == '$')
					return obj;
				return VOID;
			}
			else if (arg.charAt(0) == '$' && !contains(arg, ' ', '+', '-', '*', '/', '%', '>', '<', '=', '&', '|', '^', '?', '='))
			{
				Object obj; 
				if ((arg = fastReplace(arg, "$", "")).indexOf('.') > -1)
				{
					String[] tree = splitValues(fastReplace(fastReplace(arg, "::new", ""), "::class", ""), '.');
					Scope sc = parent.getScope(Arrays.copyOfRange(tree, 0, tree.length-1));
					obj = sc == null ? null : sc.variables().get(tree[tree.length-1]);
					/*if (sc == null || !sc.containsVariable(tree[tree.length-1]))
						System.err.println("Variable \"" + tree[tree.length-1] + "\" was not declared in \"" + arg.substring(0, arg.length() - tree[tree.length-1].length() - 1) + "\"! Defaulting to null!");*/
				}
				else
				{
					String str = fastReplace(fastReplace(arg, "::new", ""), "::class", "");
					/*if (!parent.containsVariable(str))
						System.err.println("Variable \"" + str + "\" was not declared! Defaulting to null!");*/
					obj = parent.variables().get(str);
				}

				return arg.endsWith("::class") ? obj.getClass() : arg.endsWith("::new") ? Clone(obj) : obj;
			}
		}
		return CONTINUE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object obj, Object... args) 
	{
		if (obj instanceof Entry)
		{
			Entry<Object, Object> var = (Entry<Object, Object>) obj;	
			int tabs = 0;
			if (args.length > 0)
				tabs = (int) args[0];

			boolean jsonStyle = isJsonStyle();
			return new StringBuilder().append(jsonStyle ? "\""+var.getKey()+"\"" : var.getKey()).append(var.getValue() instanceof Scope && !((Scope) var.getValue()).isEmpty() ? (jsonStyle ? " : " : " =\n" + multilpy('\t', tabs)) : (jsonStyle ? " : " : " = ")).append(DataConverter.objToString(myHomeRegistry, var.getValue(), args));
		}
		return CONTINUE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object objToDescribe, Object... argsUsedConvert) 
	{
		Entry<String, Object> ent = (Entry<String, Object>) objToDescribe;
		return new StringBuilder(DataConverter.getConverterFor(myHomeRegistry, ent.getValue(), argsUsedConvert).getDescription(myHomeRegistry, ent.getValue(), argsUsedConvert)).append(" Stored by \"").append(ent.getKey()).append("\" variable!");
	}
	
	/**
	 * @return True if variables will be serialized using json style ("key" : value)!
	 * 
	 * @since 1.3.2
	 */
	public boolean isJsonStyle() 
	{
		return jsonStyle;
	}

	/**
	 * @param jsonStyle | If true, this converter will be using Json style of variables ("key" : value)!
	 * 
	 * @since 1.3.2
	 */
	public void setJsonStyle(boolean jsonStyle) 
	{
		this.jsonStyle = jsonStyle;
	}

	/**
	 * @param s | CharSequence to search!
	 * 
	 * @return true if inserted expression is variable assignment expression such as <code>variable = 4</code> otherwise false!
	 * 
	 * @since 1.3.0
	 */
	public static boolean isVarAssignment(CharSequence s)
	{
		for (int i = 0, brackets = 0, quote = 0, len = s.length(), oldCh = -1, chNext; i < len; i++)
		{
			char ch = s.charAt(i);
			if (ch == '"')
				quote++;
	
			if (quote % 2 == 0)
			{
				if (ch == '?')
					return false;
				else if (brackets == 0 && (ch == '=' || ch == ':') && !(oldCh == '=' || oldCh == ':' || oldCh == '!' || oldCh == '>'|| oldCh == '<') && (i >= len-1 || !((chNext = s.charAt(i+1)) == '=' || chNext == ':' || chNext ==  '!' || chNext == '>'|| chNext == '<')))
					return true;	
				else if (ch == '{' || ch == '[')
					brackets++;
				else if (ch == '}' || ch == ']')
					if (brackets > 0)
						brackets--;
			}
			oldCh = ch;
		}
		return false;
	}
	
	public static int countOf(CharSequence string, char ch)
	{
		int count = 0;
		for (int i = 0, len = string.length(); i < len; i++)
		{
			if (string.charAt(i) == ch)
				count++;
		}
		return count;
	}
}
