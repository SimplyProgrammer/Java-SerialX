package ugp.org.SerialX;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

import ugp.org.SerialX.converters.DataParser;
import ugp.org.SerialX.protocols.SerializationProtocol;

	
/**
 * This is some kind of hybrid between {@link List} and {@link Map} which allow you to have both variables and independent values managed by one Object. <br>
 * Note: Variables are managed and accessed classically via {@link Map} methods such as <code>put(String key, Object)</code> and array of independent values is accessed by via {@link List} methods such as <code>add(Object)</code> and <code>get(int)</code><br>
 * This is used internally by {@link Serializer} and supposed to be read only! <br>
 * Also this is java representation of JUSS Scope group such as:
 * <pre>
 * <code>
 * {
 *     //This is scope in JUSS!
 * }
 * </code>
 * </pre>
 * 
 * @author PETO
 * 
 * @serial 1.2.0
 */
public class Scope implements Iterable<Object>, Cloneable
{
	protected LinkedHashMap<String, Object> variables;
	protected List<Object> values;
	protected final Scope parent;

	/**
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.2.0
	 */
	@SafeVarargs
	public Scope(Object... values) 
	{
		this(null, values);
	}
	
	/**
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.2.0
	 */
	@SafeVarargs
	public Scope(Map<String, ?> variablesMap, Object... values) 
	{
		this(variablesMap, values == null ? null : new ArrayList<>(Arrays.asList(values)), null);
	}
	
	/**
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * 
	 * @since 1.2.0
	 */
	public Scope(Map<String, ?> variablesMap, Collection<?> values) 
	{
		this(variablesMap, values, null);
	}
	
	/**
	 * @param variablesMap | Initial variables to be added in to this scope!
	 * @param values | Initial independent values to be added in to this scope!
	 * @param | Parent of this scope.
	 * 
	 * @since 1.2.0
	 */
	public Scope(Map<String, ?> variablesMap, Collection<?> values, Scope parent) 
	{
		variables = variablesMap == null ? new LinkedHashMap<>() : new LinkedHashMap<>(variablesMap);
		this.values = values == null ? new ArrayList<>() : new ArrayList<>(values);
		this.parent = parent;
	}
	
	@Override
	public String toString()
	{
		String name = getClass().getSimpleName();
		if (variablesCount() > 0 ^ valuesCount() > 0)
			return name + (variablesCount() > 0 ? variables() : values());
		else
			return name + toUnifiedList();
	}
	
	@Override
	public Scope clone()
	{
		return new Scope(variables(), values(), getParent());
	}
	
	/**
	 * @return Iterator of independent values.
	 * 
	 * @since 1.2.0
	 */
	@Override
	public Iterator<Object> iterator() 
	{
		return values().iterator();
	}
	
	/**
	 * Insert new variable.
	 *
	 * @param variableName | Name of variable.
	 * @param variableValue | Variables value.
	 * 
	 * @return Old value of variable with given name or null is there was no this variable before!
	 * 
	 * @since 1.2.0
	 */
	public Object put(String variableName, Object variableValue)
	{
		return variables().put(variableName, variableValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Byte value of variable with name or 0 if there is no such a one!
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public byte getByte(String variableName)
	{
		return getByte(variableName, (byte) 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Byte value of variable with name or defaultValue if there is no such a one!
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public byte getByte(String variableName, byte defaultValue)
	{
		return (byte) getInt(variableName, defaultValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Byte value of variable with name or 0 if there is no such a one!
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public short getShort(String variableName)
	{
		return getShort(variableName, (short) 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Byte value of variable with name or defaultValue if there is no such a one!
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public short getShort(String variableName, short defaultValue)
	{
		return (short) getInt(variableName, defaultValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Int value of variable with name or 0 if there is no such a one!
	 * Int will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public int getInt(String variableName)
	{
		return getInt(variableName, 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Int value of variable with name or defaultValue if there is no such a one!
	 * Int will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public int getInt(String variableName, int defaultValue)
	{
		return (int) getLong(variableName, defaultValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Long value of variable with name or 0 if there is no such a one!
	 * Long will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public int getLong(String variableName)
	{
		return getInt(variableName, 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Long value of variable with name or defaultValue if there is no such a one!
	 * Long will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public long getLong(String variableName, long defaultValue)
	{
		return (long) getDouble(variableName, defaultValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Float value of variable with name or 0 if there is no such a one!
	 * Float will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public float getFloat(String variableName)
	{
		return getFloat(variableName, 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Float value of variable with name or defaultValue if there is no such a one!
	 * Float will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public float getFloat(String variableName, float defaultValue)
	{
		return (float) getDouble(variableName, defaultValue);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Double value of variable with name or 0 if there is no such a one!
	 * Double will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public double getDouble(String variableName)
	{
		return getDouble(variableName, 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Double value of variable with name or defaultValue if there is no such a one!
	 * Double will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public double getDouble(String variableName, double defaultValue)
	{
		Object obj = get(variableName, defaultValue);
		if (obj instanceof Number)
			return ((Number) obj).doubleValue();
		else if (obj instanceof Character)
			return (double) (char) obj;
		else if (obj instanceof CharSequence)
			return Double.parseDouble(obj.toString());
		return (double) obj;
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return String value of variable with name or null if there is no such a one!
	 * String will be also parsed from any object using {@link Object#toString()}!
	 * 
	 * @since 1.2.5
	 */
	public String getString(String variableName)
	{
		return getString(variableName, null);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return String value of variable with name or defaultValue if there is no such a one!
	 * String will be also parsed from any object using {@link Object#toString()}!
	 * 
	 * @since 1.2.5
	 */
	public String getString(String variableName, String defaultValue)
	{
		Object obj = get(variableName, defaultValue);
		return obj == null ? null : obj.toString();
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Char value of variable with name or {@code (char) 0} if there is no such a one!
	 * Char will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public char getChar(String variableName)
	{
		return getChar(variableName, (char) 0);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Char value of variable with name or defaultValue if there is no such a one!
	 * Char will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public char getChar(String variableName, char defaultValue)
	{
		Object obj = get(variableName, defaultValue);
		if (obj instanceof Character)
			return (char) obj;
		else if (obj instanceof CharSequence)
			return ((CharSequence) obj).charAt(0);
		else if (obj instanceof Number)
			return (char) ((Number) obj).intValue();
		return (char) obj;
	}

	/**
	 * @param variableName | Variables name.
	 * 
	 * @return Boolean value of variable with name or false if there is no such a one!
	 * Boolean will be also parsed from {@link Number}, or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public boolean getBool(String variableName) 
	{
		return getBool(variableName, false);
	}

	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Boolean value of variable with name or defaultValue if there is no such a one!
	 * Boolean will be also parsed from {@link Number}, or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public boolean getBool(String variableName, boolean defaultValue) 
	{
		Object obj = get(variableName, defaultValue);
		if (obj instanceof Boolean)
			return (boolean) obj;
		else if (obj instanceof Number)
			return ((Number) obj).doubleValue() > 0;
		else
		{
			String str = obj.toString();
			if (str.equalsIgnoreCase("t"))
				return true;
			else if (str.equalsIgnoreCase("f"))
				return false;
			return Boolean.parseBoolean(obj.toString());
		}
	}
	
	/**
	 * @param index | Index of variable!
	 * 
	 * @return Value of variable at required index or null if index was not found!
	 * 
	 * @since 1.2.5
	 */
	public <T> T getVarAt(int index)
	{
		return getVarAt(index, null);
	}
	
	/**
	 * @param index | Index of variable!
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Value of variable at required index or defaultValue if index was not found!
	 * 
	 * @since 1.2.5
	 */
	@SuppressWarnings("unchecked")
	public <T> T getVarAt(int index, T defaultValue)
	{
		int i = 0;
		for (Map.Entry<String, Object> ent : varEntrySet())
			if (i++ == index)
				return (T) ent.getValue();
		return defaultValue;
	}
	
	/**
	 * @param variableName | Variables name.
	 * 
	 * @return Value of variable with name or null if there is no such a one!
	 * 
	 * @since 1.2.0
	 */
	public <T> T get(String variableName) 
	{
		return get(variableName, null);
	}
	
	/**
	 * @param variableName | Variables name.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Value of variable with name or defaultValue if there is no such a one!
	 * 
	 * @since 1.2.5
	 */
	@SuppressWarnings("unchecked")
	public <T> T get(String variableName, T defaultValue)
	{
		T obj = (T) variables().get(variableName);
		if (obj == null)
			return defaultValue;
		return obj instanceof Serializer.NULL ? null : obj;
	}
	
	/**
	 * @param variableName | Variables name to search for.
	 * 
	 * @return True if variable with given name was found in this scope.
	 * 
	 * @since 1.2.0
	 */
	public boolean containsVariable(String variableName) 
	{
		for (Map.Entry<String, Object> ent : varEntrySet())
			if (ent.getKey().equals(variableName))
				return true;
		return false;
	}
	
	/**
	 * @param value | Objecthe value.
	 * 
	 * @return True if independent value was found in this scope.
	 * 
	 * @since 1.2.0
	 */
	public boolean containsIndependentValue(Object value) 
	{
		return values().contains(value);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent byte value with valueIndex.
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public byte getByte(int valueIndex)
	{
		return (byte) getInt(valueIndex);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent short value with valueIndex.
	 * Byte will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public short getShort(int valueIndex)
	{
		return (short) getInt(valueIndex);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent int value with valueIndex.
	 * Int will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public int getInt(int valueIndex)
	{
		return (int) getLong(valueIndex);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent long value with valueIndex.
	 * Long will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public long getLong(int valueIndex)
	{
		return (long) getDouble(valueIndex);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent float value with valueIndex.
	 * Float will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public float getFloat(int valueIndex)
	{
		return (float) getDouble(valueIndex);
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent double value with valueIndex.
	 * Double will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public double getDouble(int valueIndex)
	{
		Object obj = get(valueIndex);
		if (obj instanceof Number)
			return ((Number) obj).doubleValue();
		else if (obj instanceof Character)
			return (double) (char) obj;
		else if (obj instanceof CharSequence)
			return Double.parseDouble(obj.toString());
		return (double) obj;
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent string value with valueIndex.
	 * String will be also parsed from any object using {@link Object#toString()}!
	 * 
	 * @since 1.2.5
	 */
	public String getString(int valueIndex)
	{
		Object obj = get(valueIndex);
		return obj == null ? null : obj.toString();
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent char value with valueIndex.
	 * Char will be also parsed from {@link Number}, {@link Character} or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public char getChar(int valueIndex)
	{
		Object obj = get(valueIndex);
		if (obj instanceof Character)
			return (char) obj;
		else if (obj instanceof CharSequence)
			return ((CharSequence) obj).charAt(0);
		else if (obj instanceof Number)
			return (char) ((Number) obj).intValue();
		return (char) obj;
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent boolean value with valueIndex.
	 * Boolean will be also parsed from {@link Number}, or {@link CharSequence} if possible!
	 * 
	 * @since 1.2.5
	 */
	public boolean getBool(int valueIndex) 
	{
		Object obj = get(valueIndex);
		if (obj instanceof Boolean)
			return (boolean) obj;
		else if (obj instanceof Number)
			return ((Number) obj).doubleValue() > 0;
		else
		{
			String str = obj.toString();
			if (str.equalsIgnoreCase("t"))
				return true;
			else if (str.equalsIgnoreCase("f"))
				return false;
			return Boolean.parseBoolean(obj.toString());
		}
	}
	
	/**
	 * @param valueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * 
	 * @return Independent value with valueIndex.
	 * 
	 * @since 1.2.0
	 */
	@SuppressWarnings("unchecked")
	public <T> T get(int valueIndex)
	{
		T obj = (T) values().get(valueIndex < 0 ? valuesCount() + valueIndex : valueIndex);
		return obj instanceof Serializer.NULL ? null : obj;
	}
	
	/**
	 * @param value | Independent value to add into array of values.
	 * 
	 * @return {@link ArrayList#add(Object)}
	 * 
	 * @since 1.2.0
	 */
	public boolean add(Object value)
	{
		return values().add(value);
	}
	
	/**
	 * @param values | List of independent value or values to add into array of values.
	 * 
	 * @return {@link ArrayList#add(Object)}
	 * 
	 * @since 1.2.0
	 */
	public boolean addAll(Collection<Object> values)
	{
		if (values.isEmpty())
			return false;
		return values().addAll(values);
	}
	
	/**
	 * @param scopeValueIndex | Index of sub-scopes value.
	 * 
	 * @return Sub-scope on required index or null if there is no scope on required index!<br>
	 * Note: Keep in mind that you need to insert valid index according to other values. Scopes share same index order with other values!
	 * 
	 * @since 1.2.0
	 */
	public Scope getScopeAt(int scopeValueIndex)
	{
		Object obj = get(scopeValueIndex);
		if (obj instanceof Scope)
			return (Scope) obj;
		return null;
	}
	
	/**
	 * @param scopesOrderIndex | Order index of sub-scope.
	 * 
	 * @return Sub-scope with required number. Similar to {@link Scope#getScopeAt(int)} however this will ignore non scope values.
	 * <br><br>
	 * For instance getScope(1) in context: <br>
	 * <pre>
	 * <code>
	 * variable = "something";
	 * "something";
	 * {
	 *      "Scope0"
	 * };
	 * 123;
	 * null;
	 * {
	 *      "Scope1" <- This one will be returned!<br>
	 * };
	 * 4;
	 * 5;
	 * 6;
	 * {
	 *      "Scope2"
	 * }
	 * </code>
	 * </pre>
	 * 
	 * @since 1.2.0
	 */
	public Scope getScope(int scopesOrderIndex)
	{
		for (int i = 0, j = 0; i < valuesCount(); i++)
		{
			Scope scope = getScopeAt(i);
			if (scope != null && j++ == scopesOrderIndex)
				return scope;
		}
		return null;
	}
	
	/**
	 * @param scopesPath | Array with variable names creating path to required scope.
	 * 
	 * @return Sub-scope stored by variable with required name (last element) in inserted path or null if there is no such a one in inserted path. If there is more than one result, the first one found will be returned!
	 * This search will also includes sub-scopes of scope but variables from lower ones are prioritize! <br>
	 * If this function is called with no arguments then self will be returned!
	 * <br>
	 * <pre>
	 * <code>
	 * variable = "something";
	 * scope1 = 
	 * {
	 *      subScope = 
	 *      {
	 *          scopeObjectoFind = {...}; <- this one will be returned if getScope("scope1", "scopeObjectoFind") is issued!
	 *          7;...
	 *      }
	 * };
	 * scopeObjectoFind = {...} <- this one will be returned if getScope("scopeObjectoFind") is issued!
	 * </code>
	 * </pre>
	 * Note: Remember that this search includes variables only, no values!
	 * 
	 * @since 1.2.0
	 */
	public Scope getScope(String... scopesPath)
	{
		if (scopesPath.length <= 0)
			return this;
		Object obj = get(scopesPath[0]);
		if (obj instanceof Scope)
			return ((Scope) obj).getScope(scopesPath = Arrays.copyOfRange(scopesPath, 1, scopesPath.length));
		for (Map.Entry<String, Object> var : varEntrySet())
			if (var.getValue() instanceof Scope)
				try 
				{
					Scope sc = (Scope) var.getValue();
					if ((sc = sc.getScope(scopesPath[0])) != null)
						return sc.getScope(scopesPath = Arrays.copyOfRange(scopesPath, 1, scopesPath.length));
				}
				catch (Exception e) {}
		if (containsVariable(scopesPath[0]))
			System.err.println("Variable with name \"" + scopesPath[0] + "\" do exists! However its value is not instance of scope, use \"get\" function instead if possible!");
			
		return null;
	}
	
	/**
	 * @param scopesValueIndex | Index of independent value. Also can be negative, in this case u will get elements from back!
	 * {@link IndexOutOfBoundsException} will be thrown if index is too big!
	 * @param objClass | Object of class to create.
	 * 
	 * @return Object of objClass constructed from independent value with scopesValueIndex! If there is no Scope stored at scopesValueIndex this function behaves same as {@link Scope#get(int)}!
	 * If independent value is {@link Scope} like it supposed to, then values of scope are parsed to {@link SerializationProtocol} of objClass.
	 * Note: Scopes are searched via regular independent value index no scope index like {@link Scope#getScope(int)}.
	 * 
	 * @see Serializer#PROTOCOL_REGISTRY
	 * @see Scope#toObject(Class)
	 * 
	 * @throws Exception if Exception occurred in {@link SerializationProtocol#unserialize(Class, Object...)}!
	 * 
	 * @since 1.2.5
	 */
	@SuppressWarnings("unchecked")
	public <T> T toObjectOf(int scopesValueIndex, Class<T> objClass) throws Exception
	{
		Object obj = get(scopesValueIndex);
		if (obj instanceof Scope)
			return ((Scope) obj).toObject(objClass);
		return (T) obj;
	}
	
	/**
	 * @param variableWithScope | Variable that supposed to contains scope.
	 * @param objClass | Object of class to create.
	 * 
	 * @return Value of variable with name or null if there is no such a one! If there is no Scope stored by variableWithScope this function behaves same as {@link Scope#get(String, Object)}!
	 * If variableWithScope contains {@link Scope} like it supposed to, then values of scope are parsed to {@link SerializationProtocol} of objClass.
	 * 
	 * @see Serializer#PROTOCOL_REGISTRY
	 * @see Scope#toObject(Class)
	 * 
	 * @throws Exception if Exception occurred in {@link SerializationProtocol#unserialize(Class, Object...)}!
	 * 
	 * @since 1.2.5
	 */
	public <T> T toObjectOf(String variableWithscope, Class<T> objClass) throws Exception
	{
		return toObjectOf(variableWithscope, objClass, null);
	}
	
	/**
	 * @param variableWithScope | Variable that supposed to contains scope.
	 * @param objClass | Object of class to create.
	 * @param defaultValue | Default value to return.
	 * 
	 * @return Value of variable with name or defaultValue if there is no such a one! If there is no Scope stored by variableWithScope this function behaves same as {@link Scope#get(String, Object)}!
	 * If variableWithScope contains {@link Scope} like it supposed to, then values of scope are parsed to {@link SerializationProtocol} of objClass.
	 * 
	 * @see Serializer#PROTOCOL_REGISTRY
	 * @see Scope#toObject(Class)
	 * 
	 * @throws Exception if Exception occurred in {@link SerializationProtocol#unserialize(Class, Object...)}!
	 * 
	 * @since 1.2.5
	 */
	@SuppressWarnings("unchecked")
	public <T> T toObjectOf(String variableWithscope, Class<T> objClass, T defaultValue) throws Exception
	{
		Object obj = get(variableWithscope, defaultValue);
		if (obj instanceof Scope)
		{
			Scope sc = (Scope) obj;
			SerializationProtocol<T> pro = (SerializationProtocol<T>) SerializationProtocol.REGISTRY.GetProtocolFor(objClass);
			if (pro == null)
			{
				System.err.println("Unable to struct variable \"" + variableWithscope + "\" as instance of \"" + objClass.getName() + "\" because there is no protocol for serializing such a class!" );
				return null;
			}
			else if (sc.variablesCount() > 0)
				return pro.unserialize(objClass, new Object[] {sc});
			return pro.unserialize(objClass, sc.toValArray());
		}
		return (T) obj;
	}
	
	/**
	 * @param objClass | Object of class to create.
	 * 
	 * @return Object of objClass constructed from this scopes independent values using protocol for objClass or null if there was no protocol found in {@link Serializer#PROTOCOL_REGISTRY}! 
	 * 
	 * @throws Exception | Exception if Exception occurred in {@link SerializationProtocol#unserialize(Class, Object...)}!
	 * 
	 * @since 1.2.5
	 */
	public <T> T toObject(Class<T> objClass) throws Exception
	{
		SerializationProtocol<T> pro = (SerializationProtocol<T>) SerializationProtocol.REGISTRY.GetProtocolFor(objClass);
		if (pro == null)
		{
			System.err.println("Unable to struct " + this + " as instance of \"" + objClass.getName() + "\" because there is no protocol for serializing such a class!" );
			return null;
		}
		else if (this.variablesCount() > 0)
			return pro.unserialize(objClass, new Object[] {this});
		return pro.unserialize(objClass, this.toValArray());
	}
	
	/**
	 * @param predicate | Predicate object with filter condition in test method!
	 * 
	 * @return Original scope after filtration using inserted predicate! If some object can't be casted to {@link Predicate#test(Object)} argument, it will be treated as invalid and will be filtered away! Sub-scopes are not included!
	 * 
	 * @since 1.2.5
	 */
	public <T> Scope filter(Predicate<T> predicate)
	{
		return filter(predicate, false);
	}
	
	/**
	 * @param predicate | Predicate object with filter condition in test method!
	 * @param includeSubScopes | If true filtration will be also applied on sub-scopes, if false sub-scopes will be treated as other things (parsed in to {@link Predicate#test(Object)}).
	 * If sub-scope is empty after filtration it will not be included in result!
	 * 
	 * @return Original scope after filtration using inserted predicate! If some object can't be casted to {@link Predicate#test(Object)} argument, it will be treated as invalid and will be filtered away!
	 * 
	 * @since 1.2.5
	 */
	public <T> Scope filter(Predicate<T> predicate, boolean includeSubScopes)
	{
		return transform(new Function<T, Object>() 
		{
			@Override
			public Object apply(T t) 
			{
				return predicate.test(t) ? t : DataParser.VOID;
			}
		}, includeSubScopes);
	}
	
	/**
	 * @param trans | Function to transform objects of this scope!
	 * 
	 * @return Original scope after transformation using inserted function! If some object can't be casted to {@link Function#apply(Object)} argument, it will be treated as invalid and will be filtered away! Sub-scopes are not included!
	 * 
	 * @since 1.2.5
	 */
	public <T> Scope transform(Function<T, Object> trans)
	{
		return transform(trans, false);
	}
	
	/**
	 * @param trans | Function to transform objects of this scope!
	 * @param includeSubScopes | If true transformation will be also applied on sub-scopes, if false sub-scopes will be treated as other things (parsed in to {@link Function#apply(Object)}).
	 * If sub-scope is empty after transformation it will not be included in result!
	 * 
	 * @return Original scope after transformation using inserted function! If some object can't be casted to {@link Function#apply(Object)} argument, it will be treated as invalid and will be filtered away!
	 * 
	 * @since 1.2.5
	 */
	@SuppressWarnings("unchecked")
	public <T> Scope transform(Function<T, Object> trans, boolean includeSubScopes)
	{
		if (trans == null || isEmpty())
			return this;

		List<Object> fltVals = new ArrayList<>();
		LinkedHashMap<String, Object> fltVars = new LinkedHashMap<>();

		for (Object obj : this)
			try
			{	
				obj = obj instanceof Serializer.NULL ? null : obj;
				if (obj instanceof Scope && includeSubScopes)
				{
					Scope sc = ((Scope) obj).transform(trans, includeSubScopes);
					if (!sc.isEmpty())
						fltVals.add(sc);
				}
				else if ((obj = trans.apply((T) obj)) != DataParser.VOID)
					fltVals.add(obj);
			}
			catch (ClassCastException e) 
			{}
		
		for (Entry<String, Object> ent : this.varEntrySet())
			try
			{
				Object obj = ent.getValue();
				obj = obj instanceof Serializer.NULL ? null : obj;
				if (obj instanceof Scope && includeSubScopes)
				{
					Scope sc = ((Scope) obj).transform(trans, includeSubScopes);
					if (!sc.isEmpty())
						fltVars.put(ent.getKey(), sc);
				}
				else if ((obj = trans.apply((T) obj)) != DataParser.VOID)
					fltVars.put(ent.getKey(), trans.apply((T) obj));
			}
			catch (ClassCastException e) 
			{}
		
		Scope resault = new Scope(fltVars, fltVals, this);
		return resault;
	}
	
	/**
	 * @param varName | Variable with name to search!
	 * 
	 * @return Values stored by variable with inserted name collected from this scope and its sub-scopes!
	 * 
	 * @since 1.3.0
	 */
	public List<Object> getAllStoredBy(String varName)
	{
		List<Object> result = new ArrayList<>();
		
		for (Entry<String, Object> var : variables().entrySet())
			if (var.getKey().equals(varName))
				result.add(var.getValue());
			else if (var.getValue() instanceof Scope)
				result.addAll(((Scope) var.getValue()).getAllStoredBy(varName));
		
		for (Object object : this) 
			if (object instanceof Scope)
				result.addAll(((Scope) object).getAllStoredBy(varName));

		return result;
	}
	
	/**
	 * @param scope | Scope whose content will be added!
	 * 
	 * @since 1.3.0
	 */
	public void addAll(Scope scope)
	{
		values().addAll(scope.values());
		variables().putAll(scope.variables());
	}
	
	/**
	 * @return Entry set of variables!
	 * 
	 * @since 1.2.0
	 */
	public Set<Entry<String, Object>> varEntrySet()
	{
		return variables().entrySet();
	}
	
	/**
	 * @return Count of keyless values of this scope!
	 * 
	 * @since 1.2.0
	 */
	public int valuesCount()
	{
		return values().size();
	}
	
	/**
	 * @return Count of variables!
	 * 
	 * @since 1.2.0
	 */
	public int variablesCount()
	{
		return variables().size();
	}
	
	/**
	 * @return True if this scope is completely empty, meaning there are no variables or values.
	 * 
	 * @since 1.2.0
	 */
	public boolean isEmpty()
	{
		return valuesCount() <= 0 && variablesCount() <= 0;
	}
	
	/**
	 * @return The parent scope of this scope or null if this scope has no parent such as default one in file.
	 * 
	 * @since 1.2.0
	 */
	public Scope getParent()
	{
		return parent;
	}
	
	/**
	 * @return New {@link LinkedHashMap} with variables of this Scope in defined order! Key is a string name of variable and value is its value! <br>
	 * Modifying this map will not affect this Scope object!
	 * 
	 * @since 1.2.0
	 */
	public LinkedHashMap<String, Object> toVarMap()
	{
		return new LinkedHashMap<>(variables());
	}
	
	/**
	 * @return New {@link ArrayList} with independent values of this Scope. These values have nothing to do with values of variables, they are independent!
	 * Modifying this list will not affect this Scope object!
	 * 
	 * @since 1.2.0
	 */
	public List<Object> toValList()
	{
		return new ArrayList<>(values());
	}
	
	/**
	 * @return Primitive array with independent values of this Scope. These values have nothing to do with values of variables, they are independent!
	 * Modifying this list will not affect this Scope object!
	 * 
	 * @since 1.2.0
	 */
	public Object[] toValArray()
	{
		return values().toArray();
	}
	
	/**
	 * @return List with both variables and values! Variables will be added as {@link Entry}!
	 * Variables will be always first!
	 * Modifying this map will not affect this Scope object!
	 * 
	 * @since 1.3.0
	 */
	public List<Object> toUnifiedList()
	{
		List<Object> list = toValList();
		list.addAll(0, varEntrySet());
		return list;
	}
	
	/**
	 * @return Values of this scope. These are not the values of keys these are values that have no key. You can access them via {@link Scope#get(int)}!
	 * Note: Editing this List will affect this scope!
	 * 
	 * @since 1.2.0
	 */
	public List<Object> values() 
	{
		return values;
	}
	
	/**
	 * @return Variables of this scope. Objecthis variables has nothing to do with values. Key is a String name of variable and value is value of variable.
	 * Note: Editing this Map will affect this scope!
	 * 
	 * @since 1.2.0
	 */
	public LinkedHashMap<String, Object> variables() 
	{
		return variables;
	}
}
