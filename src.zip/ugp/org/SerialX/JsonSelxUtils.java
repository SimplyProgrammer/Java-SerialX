package ugp.org.SerialX;

import static ugp.org.SerialX.Serializer.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

/**
 * Utility class with some methods identical with {@link Serializer} that are designed specifically to load Json using {@link JsonScope}!
 * Note: No Json specific syntax checks are made here!
 * 
 * @author PETO
 *
 * @since 1.2.5
 */
public class JsonSelxUtils 
{
	private JsonSelxUtils() {};

	/**
	 * @param file | Text file with serialized objects in Json to load.
	 * 
	 * @return Unserialized objects and variables in {@link Scope} or empty {@link Scope} if string is empty.
	 * You can use negative indexes to get objects from back of this array since 1.1.0 (-1 = last element)!
	 * 
	 * @since 1.2.5
	 */
	public static Scope LoadFrom(File file)
	{
		try 
		{
			return LoadFrom(new FileReader(file));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @param str | {@link CharSequence} with serialized objects in Json to load.
	 * 
	 * @return Unserialized objects and variables in {@link Scope} or empty {@link Scope} if string is empty.
	 * You can use negative indexes to get objects from back of this array since 1.1.0 (-1 = last element)!
	 * 
	 * @since 1.2.5
	 */
	public static Scope LoadFrom(CharSequence str)
	{
		return LoadFrom(new StringReader(str.toString()));
	}
	
	/**
	 * @param reader | Any {@link Reader} with serialized objects in Json to load.
	 * 
	 * @return Unserialized objects and variables in {@link Scope} or empty {@link Scope} if string is empty.
	 * You can use negative indexes to get objects from back of this array since 1.1.0 (-1 = last element)!
	 * 
	 * @since 1.2.5
	 */
	public static Scope LoadFrom(Reader reader)
	{
		Scope orig = LoadFromReader(reader, Serializer.globalVariables, null, true);
		return new JsonScope(orig, orig.getParent());
	}
	
	/**
	 * Regular Scope modified to meet Json needs. It helps you by eliminating necessarily of using quotes while obtaining variables!
	 * 
	 * @author PETO
	 * 
	 * @since 1.2.5
	 */
	public static class JsonScope extends Scope
	{
		/**
		 * @param scope | Scope to create JsonScope from.
		 * 
		 * @since 1.2.5
		 */
		public JsonScope(Scope scope) 
		{
			this(scope, scope.getParent());
		}
		
		/**
		 * @param scope | Scope to create JsonScope from.
		 * @param parent | Parent of this scope.
		 * 
		 * @since 1.2.5
		 */
		public JsonScope(Scope scope, Scope parent) 
		{
			super(new LinkedHashMap<>(scope.variablesCount()), scope.values(), parent);
			for (Entry<String, Object> var : scope.varEntrySet())
			{
				Object obj = var.getValue();
				if (obj.getClass().equals(Scope.class))
					put(var.getKey(), new JsonScope((Scope) obj));
				else
					put(var.getKey(), obj);
			}
			
			for (int i = 0; i < scope.valuesCount(); i++) 
			{
				Object obj = scope.values().get(i);
				if (obj.getClass().equals(Scope.class))
					values().set(i, new JsonScope((Scope) obj));
			}
		}
		
		@Override
		public Object put(String variableName, Object variableValue) 
		{
			if (Serializer.isOneOf(variableName.charAt(0), '"', '\'') && Serializer.isOneOf(variableName.charAt(variableName.length()-1), '"', '\''))
				variableName = variableName.substring(1, variableName.length()-1);
			return super.put(variableName, variableValue);
		}
	}
}
