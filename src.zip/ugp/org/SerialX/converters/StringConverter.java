package ugp.org.SerialX.converters;

import static ugp.org.SerialX.Serializer.contains;
import static ugp.org.SerialX.Serializer.indexOfNotInObj;

import ugp.org.SerialX.Registry;

/**
 * This converter is capable of converting {@link String}.
 * Its case sensitive!
 * <br>
 * <br>
 * Table of sample string <--> object conversions:
	<style>
		table, th, td 
		{
		  border: 1px solid gray;
		}
	</style>
	<table>
		<tr>
		    <th>String</th>
		    <th>Object</th> 
		</tr>
		<tr>
		    <td>"Hello world!"</td>
		    <td>new String("Hello world!")</td>
	  	</tr>
	</table>
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class StringConverter implements DataConverter
{
	/**
	 * Set this on true and {@link String} will be serialized normally, for instance <code>"Hello world!"</code> and not using protocols or java Base64! <br>
	 * Setting this on false will also make Strings unreadable for normal people!
	 * 
	 * @since 1.2.0 (moved to {@link StringConverter} since 1.3.0)
	 */
	public static boolean serializeStringNormally = true; 
	
	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object arg, Object... args) 
	{
		if (arg instanceof String)
		{
			String str = arg.toString();
			if (str.startsWith("${") && str.endsWith("}"))
			{
				str = str.substring(2, str.length()-1);
				if (str.contains("::") && indexOfNotInObj(str, ' ') > -1)
					str = "{"+str+"}";
				return str;
			}
			else if (serializeStringNormally)
			{
				if (contains(str, '"') || contains(str, '\n'))
					return CONTINUE;
				else
					return "\""+str+"\"";
			}
		}
		return CONTINUE;
	}
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args) 
	{	
		if (str.length() > 1 && str.charAt(0) == '\"' && str.charAt(str.length()-1) == '\"' && indexOfNotInObj(str, ' ') == -1)
			return str.substring(1, str.length() - 1);
		return CONTINUE;
	}
	
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object obj, Object... argsUsedConvert) 
	{
		String str = obj.toString();
		boolean hasComment = false;
		if (str.startsWith("${") && str.endsWith("}") && !(hasComment = str.substring(2).contains("//")))
			return "Manually inserted code!";
		if (!hasComment)
			return new StringBuilder().append("Object of ").append(obj.getClass().getName()).append(": \"").append(obj.toString()).append("\"!");
		return "";
	}
}
