package ugp.org.SerialX.converters;

import ugp.org.SerialX.Registry;

/**
 * This is DataParser with extended functionality! {@link DataConverter} can also parse data like DataParser but is also capable of converting them back to string!
 * This to string convertation is performed by {@link DataConverter#toString(Object)} and result of this convertation supposed to be parsable by {@link DataConverter#parse(String, Object...)} meaning one converter supposed to be parsing and converting via the same string format!
 * 
 * @see DataParser
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public interface DataConverter extends DataParser
{
	/**
	 * @param myHomeRegistry | Registry where this parser is registered provided by {@link DataParser#parseObj(Registry, String, boolean, Class[], Object...)} otherwise it demands on implementation (it should not be null)!
	 * @param obj | Object to convert into string!
	 * @param args | Some additional args. This can be anything and it demands on implementation of DataConverter. Default SerialX API implementation will provide some flags about formating!
	 * 
	 * @return Object converted to string. Easiest way to do this is obj.toString() but you most likely want some more sofisticated formating.
	 * Return {@link DataParser#CONTINUE} to tell that this converter is not suitable for converting this object! You most likely want to do this when obtained obj is not suitable instance!
	 * 
	 * @since 1.3.0
	 */
	CharSequence toString(Registry<DataParser> myHomeRegistry, Object obj, Object... args);
	
	default CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object objToDescribe, Object... argsUsedConvert) 
	{
		return "Object of " + objToDescribe.getClass().getName() + ": \""  + objToDescribe + "\" converted by " + this;
	}
	
	/**
	 * @param obj | Object to convert into string!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#toString(String, Object...)}!
	 * 
	 * @return Object converted to string using {@link DataConverter} suitable converter picked from {@link DataParser#REGISTRY}!
	 * {@link DataConverter#toString(Object, Object...)} of all registered converters will be called however only suitable ones should return the result, others should return {@link DataParser#CONTINUE}!
	 * 
	 * @since 1.3.0
	 */
	public static CharSequence objToString(Object obj, Object... args)
	{
		return objToString(REGISTRY, obj, args);
	}
	
	/**
	 * @param registry | Registry to use!
	 * @param obj | Object to convert into string!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#toString(String, Object...)}!
	 * 
	 * @return Object converted to string using {@link DataConverter} suitable converter picked from registry!
	 * {@link DataConverter#toString(Object, Object...)} of all registered converters will be called however only suitable ones should return the result, others should return {@link DataParser#CONTINUE}!
	 * 
	 * @since 1.3.0
	 */
	public static CharSequence objToString(Registry<DataParser> registry, Object obj, Object... args)
	{
		CharSequence o = null;
		for (DataParser parser : registry) 
			if (parser instanceof DataConverter)
			{
				o = ((DataConverter)parser).toString(registry, obj, args);
				if (o != CONTINUE)
					return o;
			}
		//if (o != CONTINUE)
		System.err.println(DataConverter.class.getSimpleName() + ": Unable to convert \"" + obj.getClass().getSimpleName() + "\" to string because none of registered converters were aplicable for this object!");
		return null;
	}
	
	/**
	 * @param registry | Registry to use!
	 * @param obj | Object to find converter for!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#toString(String, Object...)}!
	 * 
	 * @return Converter suitable for converting required obj to string, selected from registry!
	 */
	public static DataConverter getConverterFor(Registry<DataParser> registry, Object obj, Object... args)
	{
		for (DataParser parser : registry) 
			if (parser instanceof DataConverter && ((DataConverter)parser).toString(registry, obj, args) != CONTINUE)
				return (DataConverter) parser;
		return null;
	}
	
	/**
	 * @param applicableFor | Object to find converter for!
	 * 
	 * @return DataConverter applicable for required objects class or null if no one was found!
	 *
	@SuppressWarnings("unchecked")
	public static <O> DataConverter<O> GetConverterFor(O applicableFor)
	{
		return (DataConverter<O>) GetConverterFor(applicableFor.getClass());
	}
	
	/**
	 * @param applicableFor | Class to find converter for!
	 * 
	 * @return DataConverter applicable for required class or null if no one was found!
	 *
	@SuppressWarnings("unchecked")
	public static <O> DataConverter<O> GetConverterFor(Class<? extends O> applicableFor)
	{
		DataConverter<O> converter = null;
		for (DataParser<?> p : REGISTRY) 
			if (p instanceof DataConverter)
			{
				DataConverter<?> con = (DataConverter<?>) p;
				if (con.applicableFor().equals(applicableFor))
					return (DataConverter<O>) con;
				else if (con.applicableFor().isAssignableFrom(applicableFor))
					converter = (DataConverter<O>) con;
			}
		return converter;
	}*/
}
