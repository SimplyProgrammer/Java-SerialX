package ugp.org.SerialX.converters.operators;

import static ugp.org.SerialX.Serializer.fastReplace;
import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.converters.DataParser.parseObj;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Serializer;
import ugp.org.SerialX.converters.ArrayConverter;
import ugp.org.SerialX.converters.DataParser;
import ugp.org.SerialX.converters.NumberConverter;

/**
 * This parser provides arithmetics operators to evaluate mathematical expressions such as <code>5 * 2 +-- 2 / 2 ** 2 % 4</code> = 10!
 * 
 * @author PETO
 *
 * @since 1.3.0
 */
public class ArithmeticOperators implements DataParser 
{
	protected String[] priority1Oprs = {"*", "*-", "/", "/-", "%"}, priority2Oprs = {"**", "**-"};
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String s, Object... args) 
	{
		if (s.length() > 2)
		{
			if (indexOfNotInObj(s, '*', '/', '%') > -1) 
				return eval(myHomeRegistry, s, args);
			else 
			{
				Object obj = parseObj(myHomeRegistry, s, true, new Class[] {getClass(), NumberConverter.class, NegationOperator.class, ArrayConverter.class}, args);
				if (obj instanceof String)
				{
					if (!(s.charAt(0) == '\"' && s.charAt(s.length()-1) == '\"' && indexOfNotInObj(s, ' ') == -1) && indexOfNotInObj(obj.toString(), '+', '-') > -1)
						return eval(myHomeRegistry, obj.toString(), args);
					else
					{
						Object potentialObj = parseObj(myHomeRegistry, s, false, new Class[] {getClass()}, args);
						if (potentialObj != CONTINUE)
							return potentialObj;
					}
				}
				return obj;
			}
		}
		return CONTINUE;
	}
	
	/**
	 * @return Result of evaluated expression that was inserted! For instance 5 + 5, result 10!
	 * 
	 * @since 1.3.0
	 */
	protected Object eval(Registry<DataParser> registryForParsers, String expr, Object... argsForParsers)
	{
		while (expr.contains("++") || expr.contains("--") || expr.contains("+-") || expr.contains("-+"))
			expr = fastReplace(fastReplace(fastReplace(fastReplace(expr, "-+", "-"), "+-", "-"), "--", "+"), "++", "+");

		List<Object> cofs = getTerm(expr, false, '+', '-', '*', '/', '%'); 

		if (cofs.size() <= 1)
			return CONTINUE;
		List<Object> oprs = getTerm(expr, true, '+', '-', '*', '/', '%'); 
		
		Object cof1 = null, cof2 = null;
		String opr = null;
		try 
		{
			for (int i = 0, index = -1, orderIndex = 0; cofs.size() + oprs.size() > 1; index = -1, i++) 
			{
				for (String adept : priority1Oprs)
					if ((orderIndex = oprs.indexOf(adept)) > -1 && (index == -1 || orderIndex < index))
						index = orderIndex;
				for (String adept : priority2Oprs)
					if ((orderIndex = oprs.indexOf(adept)) > -1)
						index = orderIndex;

				cof1 = toNum(cofs.get(index = index < 0 ? 0 : index));
				if (cof1 instanceof String)
					cof1 = toNum(parseObj(registryForParsers, cof1.toString().trim(), i > 0, new Class[] {getClass(), ArrayConverter.class}, argsForParsers));
				cof1 = cof1 instanceof ResultWrapper ? ((ResultWrapper) cof1).obj : cof1;
	
			    cof2 = toNum(cofs.remove(index + 1));
			    if (cof2 instanceof String)
			    	cof2 = toNum(parseObj(registryForParsers, cof2.toString().trim(), i > 0, new Class[] {getClass()}, argsForParsers));
			    cof2 = cof2 instanceof ResultWrapper ? ((ResultWrapper) cof2).obj : cof2;
			    
				opr = oprs.remove(index).toString();
				if (opr.charAt(0) == '+')
					cofs.set(index, new ResultWrapper(add(cof1, cof2)));
				else if (opr.charAt(0) == '-')
					cofs.set(index, new ResultWrapper(sub(cof1, cof2)));
				else if (opr.startsWith("**"))
					cofs.set(index, new ResultWrapper(pow(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '*')
					cofs.set(index, new ResultWrapper(mult(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '/')
					cofs.set(index, new ResultWrapper(div(cof1, cof2, opr.endsWith("-") ? -1 : 1)));
				else if (opr.charAt(0) == '%')
					cofs.set(index, new ResultWrapper(mod(cof1, cof2)));
			}
		}
		catch (ClassCastException ex)
		{
			System.err.println("Arithmetic operator " + opr + " is undefined between " + cof1.getClass().getName() + " and " + cof2.getClass().getName() + "!");
			return null;
		}
		
		Object finalResult = cofs.get(0);
		return finalResult instanceof ResultWrapper ? ((ResultWrapper) finalResult).obj : finalResult;
	}
	
	/**
	 * @return Addition of cof and cof2 (cof + cof2)! 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object add(Object cof, Object cof2)
	{
		if (!(cof instanceof Number) || !(cof2 instanceof Number))
		{
			//System.out.println(cof + "+" + cof2);
			if (cof instanceof Collection && cof2 instanceof Collection)
				((Collection) cof).addAll(((Collection) cof2));
			return toString(cof) + toString(cof2);
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() + ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() + ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() + ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() + ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() + ((Number) cof2).doubleValue();
		return toString(cof) + toString(cof2);
	}
	
	/**
	 * @return Subtraction of cof and cof2 (cof - cof2)!
	 * 
	 * @since 1.3.0
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object sub(Object cof, Object cof2)
	{
		if (!(cof instanceof Number) || !(cof2 instanceof Number))
		{
			if (cof instanceof Collection && cof2 instanceof Collection)
				((Collection) cof).removeAll(((Collection) cof2));
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() - ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() - ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() - ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() - ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() - ((Number) cof2).doubleValue();
		return null;
	}
	
	/**
	 * @return Multiplication of cof and cof2 multiplied by sign (cof * cof2 * sign)!
	 * 
	 * @since 1.3.0
	 */
	public static Object mult(Object cof, Object cof2, int sign)
	{
		if (cof2 instanceof Number && !(cof instanceof Number))
		{
			String orig = cof.toString(), now = "";
			for (int i = 0; i < ((Number) cof2).intValue() * sign; i++) 
				now += orig;
			return now;
		}
		else if (cof instanceof Number && !(cof2 instanceof Number))
		{
			String orig = cof2.toString(), now = "";
			for (int i = 0; i < ((Number) cof).intValue() * sign; i++) 
				now += orig;
			return now;
		}
		else if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() * ((Number) cof2).doubleValue() * sign;
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() * ((Number) cof2).floatValue() * sign;
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() * ((Number) cof2).intValue() * sign;
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() * ((Number) cof2).longValue() * sign;
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() * ((Number) cof2).doubleValue() * sign;
		return null;	
	}
	
	/**
	 * @return Division of cof and cof2 multiplied by sign (cof / cof2 * sign)!
	 * 
	 * @since 1.3.0
	 */
	public static Object div(Object cof, Object cof2, int sign)
	{
		if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() / ((Number) cof2).doubleValue() * sign;
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() / ((Number) cof2).floatValue() * sign;
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() / ((Number) cof2).intValue() * sign;
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() / ((Number) cof2).longValue() * sign;
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() / ((Number) cof2).doubleValue() * sign;
		return null;	
	}
	
	/**
	 * @return Modulation of cod and cof2 (cof % cof2)!
	 * 
	 * @since 1.3.0
	 */
	public static Object mod(Object cof, Object cof2)
	{
		if (cof instanceof Double || cof2 instanceof Double)
			return ((Number) cof).doubleValue() % ((Number) cof2).doubleValue();
		else if (cof instanceof Float || cof2 instanceof Float)
			return ((Number) cof).floatValue() % ((Number) cof2).floatValue();
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return ((Number) cof).intValue() % ((Number) cof2).intValue();
		else if (cof instanceof Long || cof2 instanceof Long)
			return ((Number) cof).longValue() % ((Number) cof2).longValue();
		else if (cof instanceof Number && cof2 instanceof Number)
			return ((Number) cof).doubleValue() % ((Number) cof2).doubleValue();
		return null;	
	}
	
	/**
	 * @return Cof powered by cof2 multiplied by sign (Math.pow(cof, cof2 * sign))!
	 * 
	 * @since 1.3.0
	 */
	public static Object pow(Object cof, Object cof2, int sign)
	{
		if (cof instanceof Double || cof2 instanceof Double)
			return Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
		else if (cof instanceof Float || cof2 instanceof Float)
			return (float) Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
		else if (cof instanceof Integer || cof2 instanceof Integer)
			return (int) Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
		else if (cof instanceof Long || cof2 instanceof Long)
			return (long) Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
		else if (cof instanceof Number && cof2 instanceof Number)
			return Math.pow(((Number) cof).doubleValue(), ((Number) cof2).doubleValue() * sign);
		return null;	
	}
	
	/**
	 * 
	 * @param str | String to split!
	 * @param operatos | If true, list of spited opes will be returned otherwise terms split after each operator.
	 * @param oprs | Operators to use as a splitters.
	 * 
	 * @return List of terms splitted according to inserted arguments! For example <code>getTerm("5 + 6", true, '+')</code> will return <code>[+]</code>, while <code>getTerm("5 + 6", false, '+')</code> will return <code>[5, 6]</code>! 
	 *
	 * @since 1.3.0
	 */
	public static List<Object> getTerm(String str, boolean operatos, char... oprs)
	{
		List<Object> ret = new ArrayList<>();

		StringBuilder sb = new StringBuilder();
		for (int i = 0, len = str.length(); i < len; i++) 
			if (i > 0 || !operatos)
			{
				char ch = str.charAt(i);
				if (Serializer.isOneOf(ch, oprs) == operatos || (i == 0 && !operatos))
					sb.append(ch);
				else if (sb.length() > 0)
				{
					String s = sb.toString().trim();
					if (!s.isEmpty())
						ret.add(s);
					sb = new StringBuilder();
				}
			}
		
		if (sb.length() > 0)
		{
			String s = sb.toString().trim();
			if (!s.isEmpty())
				ret.add(s);
		}
		return ret;
	}
	
	/**
	 * @return null -> 0, bool ? 1 : 0
	 * 
	 * @since 1.3.0
	 */
	public static Object toNum(Object obj)
	{
		if (obj == null)
			return 0;
		else if (obj instanceof Boolean)
			return (boolean) obj ? 1 : 0;
		return obj; 
	}
	
	/**
	 * @return "null" if null and else obj.toString();
	 * 
	 * @since 1.3.0
	 */
	public static String toString(Object obj)
	{
		return obj == null ? "null" : obj.toString();
	}
	
	/**
	 * Used internally by {@link ArithmeticOperators} to wrap result of evaluation!
	 * 
	 * @author PET
	 *
	 * @since 1.3.0
	 */
	protected static class ResultWrapper
	{
		public final Object obj;
		
		public ResultWrapper(Object obj) 
		{
			this.obj = obj;
		}
		
		@Override
		public String toString() 
		{
			return obj.toString();
		}
	}
}
