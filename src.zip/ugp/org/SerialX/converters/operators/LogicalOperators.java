package ugp.org.SerialX.converters.operators;

import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.converters.DataParser.parseObj;
import static ugp.org.SerialX.converters.operators.ArithmeticOperators.getTerm;

import java.util.List;

import ugp.org.SerialX.Registry;
import ugp.org.SerialX.converters.DataParser;

/**
 * This parser provides logical operators to evaluate boolean expressions such as <code>false || true && true ^ false</code> = true!
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class LogicalOperators implements DataParser
{
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String s, Object... args) 
	{
		if (s.length() > 2 && indexOfNotInObj(s, '&', '|', '^') > -1)
		{
			List<Object> cofs = getTerm(s, false, '&', '|', '^');
			List<Object> oprs = getTerm(s, true, '&', '|', '^'); 

			Object cof1 = null, cof2 = null, opr = null;
			try 
			{
				for (int i = 0, index = 0; cofs.size() + oprs.size() > 1; index = 0, i++) 
				{	
					opr = oprs.remove(index);
					if (opr.equals("&&"))
					{
						cof1 = toBool(cofs.get(index)); 
						if (cof1 instanceof String)
							cof1 = toBool(parseObj(myHomeRegistry, cof1.toString().trim(), i > 0, new Class[] {getClass()}, args));
						if (cof1.equals(false))
						{
							cofs.remove(index + 1);
							cofs.set(index, false);
						}
						else
						{
							cof2 = toBool(cofs.remove(index + 1));
							if (cof2 instanceof String)
								cof2 = toBool(parseObj(myHomeRegistry, cof2.toString().trim(), i > 0, new Class[] {getClass()}, args));
							cofs.set(index, (boolean) cof1 && (boolean) cof2);
						}
					}
					else if (opr.equals("||"))
					{
						cof1 = toBool(cofs.get(index)); 
						if (cof1 instanceof String)
							cof1 = toBool(parseObj(myHomeRegistry, cof1.toString().trim(), i > 0, new Class[] {getClass()}, args));
						if (cof1.equals(true))
						{
							return true;
						}
						else
						{
							cof2 = toBool(cofs.remove(index + 1));
							if (cof2 instanceof String)
								cof2 = toBool(parseObj(myHomeRegistry, cof2.toString().trim(), i > 0, new Class[] {getClass()}, args));
							cofs.set(index, (boolean) cof1 || (boolean) cof2);
						}
					}
					else if (opr.equals("^"))
					{
						cof1 = toBool(cofs.get(index)); 
						if (cof1 instanceof String)
							cof1 = toBool(parseObj(myHomeRegistry, cof1.toString().trim(), i > 0, new Class[] {getClass()}, args));
						cof2 = toBool(cofs.remove(index + 1));
						if (cof2 instanceof String)
							cof2 = toBool(parseObj(myHomeRegistry, cof2.toString().trim(), i > 0, new Class[] {getClass()}, args));
						cofs.set(index, (boolean) cof1 ^ (boolean) cof2);
					}
				}
			}
			catch (ClassCastException ex)
			{
				System.err.println("Logical operator " + opr + " is undefined between " + cof1.getClass().getName() + " and " + cof2.getClass().getName() + "!");
				return null;
			}
			return cofs.get(0);
		}
		return CONTINUE;
	}
	
	/**
	 * @return null -> false or if number > 0
	 * 
	 * @since 1.3.0
	 */
	public static Object toBool(Object obj)
	{
		if (obj == null)
			return false;
		else if (obj instanceof Number)
			return ((Number) obj).doubleValue() > 0;
		/*else if (obj instanceof Map)
			return !((Map<?, ?>) obj).isEmpty();
		else if (obj instanceof Collection)
			return !((Collection<?>) obj).isEmpty();
		else if (obj instanceof Scope)
			return !((Scope) obj).isEmpty();
		else if (obj.getClass().isArray())
			return Array.getLength(obj) > 0;*/
		return obj;
	}
}
