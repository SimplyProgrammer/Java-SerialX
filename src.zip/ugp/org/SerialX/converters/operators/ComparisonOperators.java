package ugp.org.SerialX.converters.operators;

import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.converters.DataParser.parseObj;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;

import ugp.org.SerialX.Imports;
import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Scope;
import ugp.org.SerialX.converters.DataParser;

/**
 * This parser provides comparison operators to compare 2 objects! For example <code>6 > 5</code> or <code>5 == 5</code> returns true!
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class ComparisonOperators implements DataParser
{
	@SuppressWarnings("unchecked")
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args) 
	{
		int index = -1;
		if (str.length() > 2 && (indexOfNotInObj(str, '>', '<', '!', '=') > -1 || (index = indexOfNotInObj(str, " instanceof ")) > -1))
		{
			if (index > -1)
			{
				try 
				{
					return Imports.forName(str.substring(index+12).trim()).isInstance(parseObj(myHomeRegistry, str.substring(0, index).trim(), args));
				}
				catch (ClassNotFoundException e)
				{
					System.err.println("Unable to check if " + str.substring(0, index).trim() + " is instance of class " + str.substring(index+12).trim() + " because there is no such a class!");
					return null;
				}
			}
			else if ((index = str.indexOf("==")) > -1)
			{
				return equals(parseObj(myHomeRegistry, str.substring(0, index).trim(), args), parseObj(myHomeRegistry, str.substring(index+2).trim(), args));
			}
			else if ((index = str.indexOf("!=")) > -1) 
			{
				return !equals(parseObj(myHomeRegistry, str.substring(0, index).trim(), args), parseObj(myHomeRegistry, str.substring(index+2).trim(), args));
			}
			else if ((index = str.indexOf(">=")) > -1) 
			{
				Object obj = toCompareFriendly(parseObj(myHomeRegistry, str.substring(0, index).trim(), args)), obj2 = toCompareFriendly(parseObj(myHomeRegistry, str.substring(index+2).trim(), args));
				try
				{
					return ((Number) obj).doubleValue() >= ((Number) obj2).doubleValue();
				}
				catch (ClassCastException ex)
				{
					if (obj instanceof Comparable)
						return ((Comparable<Object>) obj).compareTo(obj2) >= 0;
					else
						System.err.println("Comparison operator >= is undefined between " + obj.getClass().getName() + " and " + obj2.getClass().getName() + "!");
					return null;
				}
			}
			else if ((index = str.indexOf("<=")) > -1) 
			{
				Object obj = toCompareFriendly(parseObj(myHomeRegistry, str.substring(0, index).trim(), args)), obj2 = toCompareFriendly(parseObj(myHomeRegistry, str.substring(index+2).trim(), args));
				try
				{
					return ((Number) obj).doubleValue() <= ((Number) obj2).doubleValue();
				}
				catch (ClassCastException ex)
				{
					if (obj instanceof Comparable)
						return ((Comparable<Object>) obj).compareTo(obj2) <= 0;
					else
						System.err.println("Comparison operator <= is undefined between " + obj.getClass().getName() + " and " + obj2.getClass().getName() + "!");
					return null;
				}
			}
			else if ((index = str.indexOf('<')) > -1) 
			{
				Object obj = toCompareFriendly(parseObj(myHomeRegistry, str.substring(0, index).trim(), args)), obj2 = toCompareFriendly(parseObj(myHomeRegistry, str.substring(index+1).trim(), args));
				try
				{
					return ((Number) obj).doubleValue() < ((Number) obj2).doubleValue();
				}
				catch (ClassCastException ex)
				{
					if (obj instanceof Comparable)
						return ((Comparable<Object>) obj).compareTo(obj2) < 0;
					else
						System.err.println("Comparison operator < is undefined between " + obj.getClass().getName() + " and " + obj2.getClass().getName() + "!");
					return null;
				}
			}
			else if ((index = str.indexOf('>')) > -1) 
			{
				Object obj = toCompareFriendly(parseObj(myHomeRegistry, str.substring(0, index).trim(), args)), obj2 = toCompareFriendly(parseObj(myHomeRegistry, str.substring(index+1).trim(), args));
				try
				{
					return ((Number) obj).doubleValue() > ((Number) obj2).doubleValue();
				}
				catch (ClassCastException ex)
				{
					if (obj instanceof Comparable)
						return ((Comparable<Object>) obj).compareTo(obj2) > 0;
					else
						System.err.println("Comparison operator > is undefined between " + obj.getClass().getName() + " and " + obj2.getClass().getName() + "!");
					return null;
				}
			}
			//System.out.println(str);
		}
		//double t = System.nanoTime();
		//System.out.println((t-t0)/1000000);
		return CONTINUE;
	}
	
	/**
	 * @return {@link Map} -> {@link Map#size()}, {@link Collection} -> {@link Collection#size()}, {@link CharSequence} -> {@link CharSequence#length()}, array -> array.length otherwise {@link ArithmeticOperators#toNum(Object)}
	 *
	 * @since 1.3.0
	 */
	public static Object toCompareFriendly(Object obj)
	{
		if (obj instanceof Map)
			return ((Map<?, ?>) obj).size();
		else if (obj instanceof Collection)
			return ((Collection<?>) obj).size();
		else if (obj instanceof Scope)
			return ((Scope) obj).valuesCount() + ((Scope) obj).variablesCount();
		else if (obj instanceof CharSequence)
			return ((CharSequence) obj).length();
		else if ((obj = ArithmeticOperators.toNum(obj)).getClass().isArray())
			return Array.getLength(obj);
		return obj;
	}
	
	/**
	 * @param obj1 | Object 1!
	 * @param obj2 | Object 2!
	 * 
	 * @return True if obj1 equals to obj2 otherwise false similar to {@link Objects#equals(Object)} but this one can handle OOP crosstype number compression such as {@link Integer} and {@link Double}!
	 * 
	 * @since 1.3.0
	 */
	public static boolean equals(Object obj1, Object obj2)
	{
		return Objects.equals(obj1, obj2) || obj1 instanceof Number && obj2 instanceof Number && ((Number) obj1).doubleValue() == ((Number) obj2).doubleValue();
	}
}
