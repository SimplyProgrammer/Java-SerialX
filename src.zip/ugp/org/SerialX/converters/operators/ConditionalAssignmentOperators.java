package ugp.org.SerialX.converters.operators;

import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.converters.DataParser.parseObj;

import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Serializer.NULL;
import ugp.org.SerialX.converters.DataParser;

/**
 * This parser provides conditional assignment operators more specially ternary and null coalescing! For example <code>true ? "Yes" : "No"</code> will return "Yes" and <code>null ?? "Hello!"</code> will return hello!
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class ConditionalAssignmentOperators implements DataParser 
{
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args) 
	{
		if (str.length() > 2 && indexOfNotInObj(str, '?', ':') > -1)
		{
			int index = str.indexOf("??");
			if (index > -1)
			{
				Object obj = parseObj(myHomeRegistry, str.substring(0, index).trim(), args);
				if (obj != null && !(obj instanceof NULL))
					return obj;
				
				String next = str.substring(index+2);
				if ((next = next.trim()).isEmpty())
					return null;
				return parseObj(myHomeRegistry, next, args);
			}
			else if ((index = str.indexOf('?')) > -1)
				try
				{
					String last = str.substring(index+1), first = str.substring(0, index);
					boolean condition = (boolean) LogicalOperators.toBool(parseObj(myHomeRegistry, first.trim(), args));
					if ((index = indexOfNotInObj(last, ':')) > -1)
					{
						first = last.substring(0, index);
						return condition ? parseObj(myHomeRegistry, first.trim(), args) : (last = last.substring(index+1).trim()).isEmpty() ? VOID : parseObj(myHomeRegistry, last, args);
					}
					else
						return condition ? parseObj(myHomeRegistry, last.trim(), args) : VOID;
				}
				catch (ClassCastException ex)
				{
					System.err.println(str.substring(0, index).trim() + " is invalid condition for ternary operator! Condition must be boolean, try to insert \"!= null\" check!");
					return null;
				}
		}
		return CONTINUE;
	}
}
