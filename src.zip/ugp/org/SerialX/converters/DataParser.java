package ugp.org.SerialX.converters;

import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Scope;
import ugp.org.SerialX.converters.operators.NegationOperator;

/**
 * This class supposed to be used to parse strings back to java objects using {@link DataParser#parse(String, Object...)}!
 * Instance of DataParser should be registered into {@link DataParser#REGISTRY} or other external registry in order to work, also only one instance of each DataParser should be used and accessed via this registry! <br>
 * Static method {@link DataParser#parseObj} is used to walk this registry and parse inserted string in process, in other words we can say that this interface contains <a href = "https://en.wikipedia.org/wiki/Recursive_descent_parser">recursive descent parse</a> that uses its own implementations!
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public interface DataParser 
{
	/**
	 * This is the way how {@link DataParser} represents void. You can return this in {@link DataParser#parse(String, Object...)} as a void.
	 * This can be useful when you are adding something to "storage" while parsing and you do not want it to be returned.
	 * 
	 * @since 1.2.2 (moved to {@link DataParser} since 1.3.0)
	 */
	public static final Object VOID = new Object();
	
	/**
	 * This is connected with {@link DataParser#parse(String, Object...)} and {@link DataParser#parseObj(String, Object...)}! And its a way to tell that this parser is not suitable for parsing obtained string and search for optimal one should continue.
	 * 
	 * @since 1.3.0
	 */
	public static final String CONTINUE = new String();
	
	/**
	 * This is DataParser registry. Here your parser implementations should be registered in order to work properly!
	 * Only one parser should be usable for specific input string, otherwise order of registration is crucial!
	 * Defaultly there are protocols from ugp.org.SerialX.converters.
	 * 
	 * @since 1.3.0
	 */
	public static final Registry<DataParser> REGISTRY = new Registry<>(new OperationGroups(), new VariableConverter(), /*new ConditionalAssignmentOperators(), new ComparisonOperators(), new LogicalOperators(), new ArithmeticOperators(),*/ new StringConverter(), new ObjectConverter(), new ArrayConverter(), new NumberConverter(), new NegationOperator(), new BooleanConverter(), new CharacterConverter(), new NullConverter(), new SerializableBase64Converter());
	
	/**
	 * @param myHomeRegistry | Registry where this parser is registered provided by {@link DataParser#parseObj(Registry, String, boolean, Class[], Object...)} otherwise it demands on implementation (it should not be null)!
	 * @param str | Source string!
	 * @param args | Some additional args. This can be anything and it demands on implementation of DataParser. Default SerialX API implementation will provide one optional argument with {@link Scope} that value was loaded from!
	 * 
	 * @return Object that was parsed from obtained string. Special return types are {@link DataParser#VOID} and {@link DataParser#CONTINUE}. Continue will ignore this parser and jump to another one in registry.
	 * 
	 * @since 1.3.0
	 */
	Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args);
	
	/**
	 * @param str | Source string to parse using suitable parser from registry.
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Object that was parsed from obtained string using suitable coverer. This method will iterate {@link DataParser#REGISTRY} and try to parse string using each registered parser until suitable return is obtained by parse method of parser, first suitable result will be returned! You can return {@link DataParser#CONTINUE} to mark parser as not suitable for parsing obtained string.
	 * If no suitable result was found, null will be returned and you will be notified in console (null does not necessary means invalid output since null can be proper result of parsing)!
	 * 
	 * @since 1.3.0
	 */
	public static Object parseObj(String str, Object... args)
	{
		return parseObj(REGISTRY, str, args);
	}
	
	/**
	 * @param registry | Registry to use!
	 * @param str | Source string to parse using suitable parser from registry.
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Object that was parsed from obtained string using suitable coverer. This method will iterate registry and try to parse string using each registered parser until suitable return is obtained by parse method of parser, first suitable result will be returned! You can return {@link DataParser#CONTINUE} to mark parser as not suitable for parsing obtained string.
	 * If no suitable result was found, null will be returned and you will be notified in console (null does not necessary means invalid output since null can be proper result of parsing)!
	 * 
	 * @since 1.3.0
	 */
	public static Object parseObj(Registry<DataParser> registry, String str, Object... args)
	{
		return parseObj(registry, str, false, null, args);
	}
	
	/**
	 * @param registry | Registry to use!
	 * @param str | Source string to parse using suitable parser from registry.
	 * @param returnAsStringIfNotFound | If true, inserted string will be returned instead of null and error message!
	 * @param ignore | {@link DataParser} class to ignore!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Object that was parsed from obtained string using suitable coverer. This method will iterate registry and try to parse string using each registered parser until suitable return is obtained by parse method of parser, first suitable result will be returned! You can return {@link DataParser#CONTINUE} to mark parser as not suitable for parsing obtained string.
	 * If no suitable result was found, null or inserted string will be returned based on returnAsStringIfNotFound!
	 * 
	 * @since 1.3.0
	 */
	public static Object parseObj(Registry<DataParser> registry, String str, boolean returnAsStringIfNotFound, Class<?>[] ignore, Object... args)
	{
		Object obj = null;
		
		registryLoop: for (DataParser parser : registry)
		{
			if (ignore != null)
				for (Class<?> cls : ignore) 
					if (cls == parser.getClass())
						continue registryLoop;
			
			obj = parser.parse(registry, str, args);
			if (obj != CONTINUE)
				return obj;
		}

		if (returnAsStringIfNotFound)
			return str;
		//if (obj != CONTINUE)
		System.err.println(DataParser.class.getSimpleName() + ": Unable to parse \"" + str + "\" because none of registred parsers were suitable!");
		return null;
	}
	
	/**
	 * @param registry | Registry to search!
	 * @param str | String to find parser for!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Parser suitable for parsing required string, selected from {@link DataParser#REGISTRY}!
	 * 
	 * @since 1.3.0
	 */
	public static DataParser getParserFor(String str, Object... args)
	{
		return getParserFor(REGISTRY, str, args);
	}
	
	/**
	 * @param registry | Registry to search!
	 * @param str | String to find parser for!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Parser suitable for parsing required string, selected from inserted registry!
	 * 
	 * @since 1.3.0
	 */
	public static DataParser getParserFor(Registry<DataParser> registry, String str, Object... args)
	{
		for (DataParser parser : registry) 
			if (parser.parse(registry, str, args) != CONTINUE)
				return parser;
		return null;
	}
}
