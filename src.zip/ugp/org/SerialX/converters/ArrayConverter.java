package ugp.org.SerialX.converters;

import static ugp.org.SerialX.Serializer.ToClasses;
import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.Serializer.splitValues;

import java.lang.reflect.Array;

import ugp.org.SerialX.Registry;

/**
 * This converter is capable of converting primitive arrays. 
 * Its case sensitive!
 * <br>
 * <br>
 * Table of sample string <--> object conversions:
	<style>
		table, th, td 
		{
		  border: 1px solid gray;
		}
	</style>
	<table>
		<tr>
		    <th>String</th>
		    <th>Object</th> 
		</tr>
		<tr>
		    <td>1 2 3</td>
		    <td>new int[] {1, 2, 3}</td>
	  	</tr>
	    <tr>
		    <td>4 5 "hello!"</td>
		    <td>new Object[] {4, 5, "hello!"}</td>
		</tr>
	  	<tr>
		    <td>"Lorem" "ipsum"</td>
		    <td>new String[] {"Lorem", "ipsum"}</td>
		</tr>
	</table>
 *
 * @author PETO
 * 
 * @since 1.3.0
 */
public class ArrayConverter implements DataConverter
{
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... args) 
	{
		if (indexOfNotInObj(str, ' ') > -1)
		{
			boolean findArrType = true;
			if (args.length > 1 && args[1] instanceof Boolean)
				findArrType = (boolean) args[1];
			
			String[] strObjs = splitValues(str, ' ');
			Object[] objs = new Object[strObjs.length];
			
			Class<?> arrClass = null;
			for (int i = 0; i < objs.length; i++) 
			{
				Object obj = objs[i] = DataParser.parseObj(myHomeRegistry, strObjs[i], args);
				if (obj != null)
					if (arrClass == null)
						arrClass = obj.getClass();
					else if (arrClass != obj.getClass())
						arrClass = Object.class;	
			}
			
			if (findArrType && arrClass != null && !arrClass.equals(Object.class))
			{
				Object arr = Array.newInstance(ToClasses(arrClass)[0], objs.length);
				for (int i = 0; i < objs.length; i++) 
					Array.set(arr, i, objs[i]);
				return arr;
			}
			return objs;
		}
		return CONTINUE;
	}

	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object obj, Object... args) 
	{
		if (obj != null && myHomeRegistry != null && obj.getClass().isArray())
		{
			int tabs = 0, index = 0;
			if (args.length > 1)
				index = (int) args[1];
			
			if (index <= 0 || myHomeRegistry.indexOf(OperationGroups.class) > -1)
			{
				if (args.length > 0)
					tabs = (int) args[0];
				
				if (args.length > 1)
					args[1] = (int) args[1] + 1;
				
				StringBuilder sb = new StringBuilder();
				for (int i = 0, length = Array.getLength(obj), sizeEndl = 10000; i < length; i++) 
				{
					CharSequence str = DataConverter.objToString(myHomeRegistry, Array.get(obj, i), args);
					char ch = str.charAt(0);
					if (ch == '{' || ch == '[')
						sb.append("("+str+")");
					else
						sb.append(str);
						
					if (i < length-1)
						if (sb.length() > sizeEndl)
						{
							sb.append("\n"); 
							for (int j = 0; j < tabs+1; j++) 
								sb.append("\t");
							sizeEndl += 10000;
						}
						else 
							sb.append(' ');
				}
				return index > 0 ? sb.insert(0, '(').append(')') : sb;
			}
		}
		return CONTINUE;
	}
	
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object objToDescribe, Object... argsUsedConvert) 
	{
		return "Primitive array " + objToDescribe + " converted by " + getClass().getName();
	}
}