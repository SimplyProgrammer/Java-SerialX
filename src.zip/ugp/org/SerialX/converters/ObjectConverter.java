package ugp.org.SerialX.converters;

import static ugp.org.SerialX.Serializer.InvokeStaticFunc;
import static ugp.org.SerialX.Serializer.LoadFrom;
import static ugp.org.SerialX.Serializer.SerializeTo;
import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.Serializer.isOneOf;
import static ugp.org.SerialX.Serializer.multilpy;
import static ugp.org.SerialX.Serializer.splitValues;

import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import ugp.org.SerialX.Imports;
import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Scope;
import ugp.org.SerialX.protocols.SerializationProtocol;

/**
 * This converter is capable of converting any Object using {@link SerializationProtocol} as well as invoking static functions!
 * Its case sensitive!
 * <br>
 * <br>
 * Table of sample string <--> object conversions:
 * 	<style>
		table, th, td 
		{
		  border: 1px solid gray;
		}
	</style>
	<table>
		<tr>
		    <th>String</th>
		    <th>Object</th> 
		</tr>
		<tr>
		    <td>ArrayList 2 4 6</td>
		    <td>new ArrayList<>(Arrays.asList(2, 4, 6))</td>
	  	</tr>
		<tr>
		    <td>java.lang.Math::max 10 5</td>
		    <td>10</td>
	  	</tr>
	</table>
 * 
 * @author PETO
 * 
 * @since 1.3.0
 */
public class ObjectConverter implements DataConverter 
{
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String str, Object... compilerArgs) 
	{
		Class<?> objectClass = null;
		boolean hasOp, hasCls = false;
		char ch;

		if (str.length() > 0 && ((hasOp = (ch = str.charAt(0)) == '{' || ch == '[') && (hasCls = (ch = str.charAt(str.length()-1)) == '}' || ch == ']') /*|| containsNotInObj(str, ' ')*/ || (objectClass = getProtocolExprClass(str)) != null))
		{
			if (objectClass != null)
			{
				if (objectClass == IsSelectorScope.class)
				{
					StringBuilder sb = new StringBuilder(str);
					sb.setCharAt(str.indexOf(' '), '=');
					return DataParser.parseObj(myHomeRegistry, sb.toString(), compilerArgs);
				}
				String[] args = splitValues(str = str.trim(), ' ');	
				if (!isOneOf(args[0].charAt(0), '{', '[') && args[0].contains("::"))
				{
					String[] clsAttr = args[0].split("::");
					if (clsAttr.length > 1)
					{
						if (args.length > 1)
							try
							{
								return InvokeStaticFunc(objectClass, clsAttr[1], parseAll(myHomeRegistry, args, 1, true, compilerArgs));
							}
							catch (InvocationTargetException e) 
							{
								System.err.println("Exception while calling method \"" + clsAttr[1] + "\":");
								e.printStackTrace();
							}
						else
							try
							{
								return clsAttr[1].equals("class") ? objectClass : clsAttr[1].equals("new") ? objectClass.getConstructor().newInstance() : objectClass.getField(clsAttr[1]).get(null);
							}
							catch (NoSuchFieldException e)
							{
								try
								{
									return InvokeStaticFunc(objectClass, clsAttr[1], parseAll(myHomeRegistry, args, 1, true, compilerArgs));
								}
								catch (InvocationTargetException e2) 
								{
									System.err.println("Exception while calling method \"" + clsAttr[1] + "\":");
									e.printStackTrace();
								}
							}
							catch (Exception e) 
							{
								System.err.println("Unable to obtain value of field \"" + clsAttr[1] + "\" in class \"" + objectClass.getSimpleName() + "\" because:");
								e.printStackTrace();
							}
					/*catch (ClassNotFoundException e) 
					{
						System.err.println("Unable to invoke \"" + args[0].split("::")[1] + "\" because class \"" + args[0].split("::")[0] + "\" was not found!");
					} */
					}
				}
				else
					try
					{
						if (isOneOf(str.charAt(str.length()-1), ';', ','))
							throw new ClassNotFoundException();
						Object[] objArgs = parseAll(myHomeRegistry, args, 1, true, compilerArgs);	
						return SerializationProtocol.unserializeObj(objectClass, objArgs);
						/*Object obj;
						if (objArgs.length == 1 && objArgs[0] instanceof Scope)
						{
							Scope scope = (Scope) objArgs[0];
							if ((obj = p.unserialize(objectClass, scope.toValArray())) != null)
								return obj;
							return p.unserialize(objectClass, scope);
						}
						else
						{
							if ((obj = p.unserialize(objectClass, objArgs)) != null)
								return obj;
							return p.unserialize(objectClass, new Scope(objArgs));
						}*/
					}
					catch (Exception e) 
					{
						System.err.println("Exception while unserializing instance of \"" + objectClass.getName() + "\":");
						e.printStackTrace();
					}
			}
			else
			{
				Scope parent = null;
				if (compilerArgs.length > 0 && compilerArgs[0] instanceof Scope)
					parent = (Scope) compilerArgs[0];

				if (indexOfNotInObj(str, '=', ':', ';', ',') > -1)
					return LoadFrom(new StringReader(str), parent, false);
				else if (hasOp && hasCls)
				{
					str = str.substring(1, str.length()-1).trim();
					if (str.isEmpty())
						return new Scope(null, null, parent);
					int index;
					if ((index = indexOfNotInObj(str, '=', ';', ',')) > -1 && (index >= str.length()-1 || str.charAt(index+1) != ':') || (objectClass = getProtocolExprClass(str)) == null || objectClass == IsSelectorScope.class)
						return LoadFrom(new StringReader(str), parent, false);
					if (objectClass != null && indexOfNotInObj(str, "::") > -1)
						return DataParser.parseObj(myHomeRegistry, str, compilerArgs);
					return parse(myHomeRegistry, str, compilerArgs);
				}
				else if (str.split(" ").length > 1)
				{
					System.err.println("Unable to unserialize \"" + str + "\"! Possible reason of this is absence of comma or semicolon, try to insert them into empty spaces!");
					return null;
				}
			}
			System.err.println("Unable to unserialize \"" + str + "\" because there is no such class or source string is corrupted!");
			return null;
		}
		return CONTINUE;
	}

	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object arg, Object... args) 
	{
		if (arg == null)
			return CONTINUE;
		
		int tabs = 0, index = 0;
		if (args.length > 0)
			tabs = (int) args[0];
		
		if (arg instanceof Scope)
		{
			Scope sc = (Scope) arg;
			if (sc.isEmpty())
				return "{}";
			else
			{
				//boolean verticalLayout = true;//sc.variablesCount() > 0 || sc.valuesCount() == 1;
				StringBuilder sb = SerializeTo(new StringBuilder("{"), tabs+1, sc.toVarMap(), sc.toValArray());
				//if (verticalLayout)
				sb.insert(1, "\n").append("\n").append(multilpy("\t", tabs));

				return sb.append('}');
			}
		}
		else
		{
			SerializationProtocol<Object> prot = SerializationProtocol.REGISTRY.GetProtocolFor(arg);
			if (prot != null)
			{
				Object[] objArgs = prot.serialize(arg);
				StringBuilder sb = new StringBuilder(Imports.getAliasFor(arg.getClass()) + (objArgs.length <= 0 ? "" : " "));
				if (args.length > 1)
					index = (int) args[1];
				
				for (int i = 0, sizeEndl = 10000; i < objArgs.length; i++) 
				{
					if (args.length > 1)
						args[1] = (int) args[1] + 1;
					sb.append(DataConverter.objToString(myHomeRegistry, objArgs[i], args));
					if (i < objArgs.length-1)
						if (sb.length() > sizeEndl)
						{
							sb.append("\n"); 
							for (int j = 0; j < tabs+1; j++) 
								sb.append("\t");
							sizeEndl += 10000;
						}
						else 
							sb.append(' ');
				}
				
				return index > 0 ? sb.insert(0, '{').append('}') : sb;
			}
		}
		return CONTINUE;
	}
	
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object obj, Object... argsUsedConvert) 
	{
		if (obj instanceof Scope && ((Scope) obj).isEmpty())
			return "Empty scope!";
		return new StringBuilder("Object of ").append(obj.getClass().getName()).append(": \"").append(obj.toString()).append("\" serialized using ").append(SerializationProtocol.REGISTRY.GetProtocolFor(obj).toString()).append("!");
	}
	
	/**
	 * @param str | String to check protocol class for!
	 * 
	 * @return Class of the protocol or null if inserted statement is not protocol expression!
	 * For example: <code>getProtocolExprClass("java.util.ArrayList 1 2 3 4 5")</code> will return {@link ArrayList} but <code>"Hello world!"</code> will return null!
	 *
	 * @since 1.3.0
	 */
	public static Class<?> getProtocolExprClass(String str)
	{
		int i = 0, len = str.length();
		for (; i < len; i++)
		{
			char ch = str.charAt(i);
			if (ch == ' ' || ch == ':')
				break;
		}

		try 
		{
			Class<?> cls = Imports.forName(str.substring(0, i), false, ObjectConverter.class.getClassLoader());
			if (cls != null)
				return cls;
			for (; i < len; i++)
			{
				char ch = str.charAt(i); 
				if (ch > 32)
					if (ch == '{' || ch == '[')
						return IsSelectorScope.class;
					else
						return null;
			}
		} 
		catch (ClassNotFoundException e) 
		{}
		return null;
	}
	
	/**
	 * @param registry | Registry to use!
	 * @param strs | Source strings to parse using suitable parser from registry.
	 * @param from | Start index to begin from!
	 * @param trim | If true, all strings will be trimed before parsing!
	 * @param args | Additional arguments that will be obtained in {@link DataParser#parse(String, Object...)}!
	 * 
	 * @return Array of parsed objects, each parsed using {@link DataParser#parseObj(String, Object...)}
	 * 
	 * @since 1.3.0
	 */
	public static Object[] parseAll(Registry<DataParser> registry, String strs[], int from, boolean trim, Object... args)
	{
		Object[] objs = new Object[strs.length-from];
		for (int i = 0; from < strs.length; from++, i++) 
			objs[i] = DataParser.parseObj(registry, trim ? strs[from].trim() : strs[from], args);
		return objs;
	}
	
	/**
	 * Dummy class with no purpose except to be mark (.class) for shortened scope expression such as:
	 * <code>
	 * shortenedSelectorLikeScope {<br><br>
	 * 		//stuff...
	 * };
	 * </code>
	 * 
	 * @author PETO
	 *
	 * @since 1.3.0
	 */
	protected class IsSelectorScope {};
}
