package ugp.org.SerialX.converters;

import static ugp.org.SerialX.Serializer.Clone;
import static ugp.org.SerialX.Serializer.ParseObjectHandleNull;
import static ugp.org.SerialX.Serializer.contains;
import static ugp.org.SerialX.Serializer.fastReplace;
import static ugp.org.SerialX.Serializer.indexOfNotInObj;
import static ugp.org.SerialX.Serializer.isOneOf;
import static ugp.org.SerialX.Serializer.multilpy;
import static ugp.org.SerialX.Serializer.splitValues;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import ugp.org.SerialX.Registry;
import ugp.org.SerialX.Scope;

/**
 * This converter is capable of converting {@link Map.Entry} and reading variables from {@link Scope} via "$"!
 * {@link VariableConverter#parse(String, Object...)} required one additional Scope argument in args... argument!
 * Its case insensitive!<br>
 * Exact outputs of this converter are based on inserted scope!
 * 
 * @author PETO
 *	
 * @since 1.3.0
 */
public class VariableConverter implements DataConverter
{
	/**
	 * Raw example of variable entry this converter can convert!
	 * 
	 * @since 1.3.0 
	 */
	public static final Entry<String, Object> RAW_VAR_ENTRY = new Entry<String, Object>() 
	{
		@Override
		public String getKey() 
		{
			return "";
		}

		@Override
		public Object getValue()
		{
			return null;
		}

		@Override
		public Object setValue(Object value) 
		{
			return null;
		}
	};
	
	@Override
	public Object parse(Registry<DataParser> myHomeRegistry, String arg, Object... args) 
	{
		if (args.length > 0 && args[0] instanceof Scope)
		{
			Scope parent = (Scope) args[0];
			if (isVarAssignment(arg))
			{
				String[] enrty;
				if (isOneOf(arg.charAt(0), '=', ':'))
					enrty = new String[] {"", arg.substring(1)};
				else
					enrty = splitValues(arg, 2, '=', ':');
				if (indexOfNotInObj(enrty[0], '.') > -1)
				{
					System.err.println(arg + " cant be set because scope variables are final or variable does not even exists!");
					return VOID;
				}
				else if (contains(enrty[0] = enrty[0].trim(), ' '))
				{
					System.err.println("Variable name cannot contains blank characters!");
					return VOID;
				}

				Object obj = null;
				if (enrty.length > 1 && !enrty[1].isEmpty())
				{
					/*if (isVarAssignment(enrty[1]))
					{
						if (args.length < 4)
							args = Arrays.copyOf(args.clone(), 4);
						args[3] = true;
						obj = ParseObjectHandleNull(myHomeRegistry, enrty[1], true, args);
					}
					else
					{*/
					obj = ParseObjectHandleNull(myHomeRegistry, enrty[1], true, args);
					//}
				}
				
				if (obj != VOID)
				{
					parent.put(fastReplace(enrty[0], "$", ""), obj);
					if (arg.startsWith("$"))
						return obj;
				}
				else
					parent.variables().remove(enrty[0]);
				return VOID;
			}
			else if (arg.charAt(0) == '$' && !contains(arg, ' ', '+', '-', '*', '/', '%', '>', '<', '=', '&', '|', '^', '?', '='))
			{
				Object obj; 
				if (contains(arg = fastReplace(arg, "$", ""), '.'))
				{
					String[] tree = splitValues(fastReplace(fastReplace(arg, "::new", ""), "::class", ""), '.');
					Scope sc = parent.getScope(Arrays.copyOfRange(tree, 0, tree.length-1));
					obj = sc == null ? null : sc.variables().get(tree[tree.length-1]);
					/*if (sc == null || !sc.containsVariable(tree[tree.length-1]))
						System.err.println("Variable \"" + tree[tree.length-1] + "\" was not declared in \"" + arg.substring(0, arg.length() - tree[tree.length-1].length() - 1) + "\"! Defaulting to null!");*/
				}
				else
				{
					String str = fastReplace(fastReplace(arg, "::new", ""), "::class", "");
					/*if (!parent.containsVariable(str))
						System.err.println("Variable \"" + str + "\" was not declared! Defaulting to null!");*/
					obj = parent.variables().get(str);
				}

				return arg.endsWith("::class") ? obj.getClass() : arg.endsWith("::new") ? Clone(obj) : obj;
			}
		}
		return CONTINUE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CharSequence toString(Registry<DataParser> myHomeRegistry, Object obj, Object... args) 
	{
		if (obj instanceof Entry)
		{
			Entry<Object, Object> var = (Entry<Object, Object>) obj;	
			int tabs = 0;
			if (args.length > 0)
				tabs = (int) args[0];
			
			return new StringBuilder().append(var.getKey()).append(var.getValue() instanceof Scope && !((Scope) var.getValue()).isEmpty() ? " =\n"+multilpy("\t", tabs) : " = ").append(DataConverter.objToString(myHomeRegistry, var.getValue(), args));
		}
		return CONTINUE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CharSequence getDescription(Registry<DataParser> myHomeRegistry, Object objToDescribe, Object... argsUsedConvert) 
	{
		Entry<String, Object> ent = (Entry<String, Object>) objToDescribe;
		return new StringBuilder(DataConverter.getConverterFor(myHomeRegistry, ent.getValue(), argsUsedConvert).getDescription(myHomeRegistry, ent.getValue(), argsUsedConvert)).append(" Stored by \"").append(ent.getKey()).append("\" variable!");
	}
	
	/**
	 * @param s | CharSequence to search!
	 * 
	 * @return true if inserted expression is variable assignment expression such as <code>variable = 4</code> otherwise false!
	 * 
	 * @since 1.3.0
	 */
	public static boolean isVarAssignment(CharSequence s)
	{
		for (int i = 0, brackets = 0, quote = 0, len = s.length(), oldCh = -1, chNext; i < len; i++)
		{
			char ch = s.charAt(i);
			if (ch == '"')
				quote++;
	
			if (quote % 2 == 0)
			{
				if (ch == '?')
					return false;
				else if (brackets == 0 && (ch == '=' || ch == ':') && !(oldCh == '=' || oldCh == ':' || oldCh == '!' || oldCh == '>'|| oldCh == '<') && (i >= len-1 || !((chNext = s.charAt(i+1)) == '=' || chNext == ':' || chNext ==  '!' || chNext == '>'|| chNext == '<')))
					return true;
				else if (ch == '{' || ch == '[')
					brackets++;
				else if (ch == '}' || ch == ']')
					if (brackets > 0)
						brackets--;
			}
			oldCh = ch;
		}
		return false;
	}
}
