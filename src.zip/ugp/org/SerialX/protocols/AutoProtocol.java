package ugp.org.SerialX.protocols;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import ugp.org.SerialX.Serializer;

/**
 * This is automatic protocol that will automatically serialize every or selected field in object that has valid and public getter and setter!
 * This protocol is applicable on anything you want however condition of use is absence of final field otherwise {@link AutoProtocol#createBlankInstance(Class)} should be overridden. ALso you should {@link AutoProtocol#createBlankInstance(Class)} when you object is to complex!
 * 
 * @author PETO
 *
 * @param <T> | Generic type of object to use protocol for.
 * 
 * @since 1.2.2
 */
public class AutoProtocol<T> extends SerializationProtocol<T> 
{
	protected final Class<T> applicableFor;
	protected final List<PropertyDescriptor> variables = new ArrayList<>();
	
	/**
	 * @param applicableFor | Class that can be serialized using this protocol.
	 * @param fieldNamesToSerialize | Names of fields to serialize, if empty array is put there then all fields with public and valid getters and setters will be serialized!
	 * 
	 * @throws IntrospectionException when there are no field with valid and public getters and setters.
	 * 
	 * @since 1.2.2
	 */
	public AutoProtocol(Class<T> applicableFor, String... fieldNamesToSerialize) throws IntrospectionException
	{
		this.applicableFor = applicableFor;
		if (fieldNamesToSerialize.length <= 0)
		{
	        for (Class<?> c = applicableFor; c != Object.class; c = c.getSuperclass())
				for (Field field : c.getDeclaredFields())
					if (!Modifier.isStatic(field.getModifiers()) && !Modifier.isFinal(field.getModifiers()))
						try
						{
							variables.add(new PropertyDescriptor(field.getName(), applicableFor));
						}
						catch (Exception e)
						{
							
						}
	       
			if (variables.isEmpty())
				throw new IntrospectionException("No fields with valid and public getters and setters to use in " + applicableFor.getSimpleName());
		}
		else
		{
			for (int i = 0; i < fieldNamesToSerialize.length; i++) 
				variables.add(new PropertyDescriptor(fieldNamesToSerialize[i], applicableFor));
		}
	}
	
	/**
	 * @param objectClass | Class to create new instance of!
	 * 
	 * @return New blank instance of required class! When not override, it returns {@link Serializer#Instantiate(objectClass)} 
	 * 
	 * @throws Exception if any exception occurs (based on implementation).
	 * 
	 * @since 1.2.2
	 */
	public T createBlankInstance(Class<? extends T> objectClass) throws Exception
	{
		return Serializer.Instantiate(objectClass);
	}
	
	@Override
	public Object[] serialize(T object)
	{
		try
		{
			Object[] args = new Object[variables.size()];
			for (int i = 0; i < variables.size(); i++) 
				args[i] = variables.get(i).getReadMethod().invoke(object);
			return args;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public T unserialize(Class<? extends T> objectClass, Object... args) throws Exception 
	{
		T obj = createBlankInstance(objectClass);
		for (int i = 0; i < variables.size(); i++) 
			variables.get(i).getWriteMethod().invoke(obj, args[i]);
		return obj;
	}

	@Override
	public Class<? extends T> applicableFor() 
	{
		return applicableFor;
	}
}
