package ugp.org.SerialX.protocols;

import java.util.Arrays;
import java.util.Collection;

/**
 * ListProtocol is universal protocol to serialize any {@link Collection} instance. The condition of use is public constructor with one {@link Collection} argument.
 * 
 * @author PETO
 *
 * @since 1.0.0 and applicable for {@link Collection} since 1.2.2
 */
public class ListProtocol extends SerializationProtocol<Collection<Object>> 
{
	@Override
	public Object[] serialize(Collection<Object> obj) 
	{
		return obj.toArray();
	}

	@Override
	public Collection<Object> unserialize(Class<? extends Collection<Object>> objectClass, Object... args) throws Exception
	{
		return objectClass.getConstructor(Collection.class).newInstance(Arrays.asList(args));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<? extends Collection<Object>> applicableFor() 
	{
		return (Class<? extends Collection<Object>>) Collection.class;
	}
}
