package ugp.org.SerialX.protocols;

import java.util.HashMap;
import java.util.Map;

import ugp.org.SerialX.Scope;
import ugp.org.SerialX.converters.DataConverter;

/**
 * ScopeProtocol is universal protocol to serialize any {@link Scope} instance. The condition of use is public constructor with arguments {@link Map} and Object[]! <br>
 * Note: This protocol is unique in some way because it works for read only because scopes are normally serialized via {@link DataConverter} meaning calling serialize method will throw exception right away! But under normal circumstances protocols like this should not exist!
 * 
 * @author PETO
 *
 * @since 1.2.2
 */
public class ScopeProtocol extends SerializationProtocol<Scope> 
{
	@Override
	public Object[] serialize(Scope object) 
	{
		throw new UnsupportedOperationException(getClass().getSimpleName() + ": You are trying to serialize Scope via protocol! This is not good and should not even be possible! Scopes are meant to be serialized via converters!");
	}

	@Override
	public Scope unserialize(Class<? extends Scope> objectClass, Object... args) throws Exception 
	{
		if (args.length == 1 && args[0] instanceof Scope)
			return objectClass.getConstructor(Map.class, Object[].class).newInstance(((Scope) args[0]).toVarMap(), ((Scope) args[0]).toValArray());
		return objectClass.getConstructor(Map.class, Object[].class).newInstance(new HashMap<>(), args);
	}

	@Override
	public Class<? extends Scope> applicableFor() 
	{
		return Scope.class;
	}
}
