package ugp.org.SerialX.protocols;

import java.lang.reflect.Constructor;
import java.util.Arrays;

import ugp.org.SerialX.Serializer;

/**
 * SelfSerializableProtocol is universal protocol to serialize any {@link SelfSerializable} instance. The condition of use is implementation of {@link SelfSerializable} interface and public constructor that can be called with content returned by specific {@link SelfSerializable#serialize()}!
 * 
 * @author PETO
 *
 * @since 1.2.2	
 */
public class SelfSerializableProtocol extends SerializationProtocol<SelfSerializable> 
{
	@Override
	public Object[] serialize(SelfSerializable object) 
	{
		return object.serialize();
	}

	@Override
	public SelfSerializable unserialize(Class<? extends SelfSerializable> objectClass, Object... args) throws Exception 
	{
		try 
		{
			return objectClass.getConstructor(Serializer.ToClasses(args)).newInstance(args);
		}
		catch (Exception find) 
		{
			for (Constructor<?> cons : objectClass.getConstructors()) 
				try
				{
					return (SelfSerializable) cons.newInstance(args);
				}
				catch (IllegalArgumentException e) 
				{}
				catch (SecurityException | IllegalAccessException ex)
				{
					ex.printStackTrace();
				}
		}
		System.err.println(getClass().getSimpleName() +": Unable to call create new instance of \"" + objectClass + "\" because inserted arguments " + Arrays.asList(args) + " cannot be applied on any public constructor in required class!");
		return null;
	}

	@Override
	public Class<? extends SelfSerializable> applicableFor() 
	{
		return SelfSerializable.class;
	}
}
